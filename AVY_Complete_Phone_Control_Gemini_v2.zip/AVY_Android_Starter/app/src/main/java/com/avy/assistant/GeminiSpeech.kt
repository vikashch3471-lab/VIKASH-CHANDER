package com.avy.assistant

import android.content.Context
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** Online Gemini speech synthesis. Caller must use Android TTS if this returns null. */
object GeminiSpeech {
    private const val MODEL = "gemini-3.8-flash-tts"

    fun synthesize(context: Context, text: String, callback: (File?) -> Unit) {
        val key = GeminiBrain.getApiKey(context)
        if (key.isBlank() || text.isBlank()) { callback(null); return }
        Thread {
            var connection: HttpURLConnection? = null
            var result: File? = null
            try {
                val endpoint = "https://generativelanguage.googleapis.com/v1beta/interactions"
                connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 20000
                    readTimeout = 60000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    setRequestProperty("x-goog-api-key", key)
                }
                val request = JSONObject()
                    .put("model", MODEL)
                    .put("input", JSONArray().put(JSONObject()
                        .put("type", "user_input")
                        .put("content", JSONArray().put(JSONObject()
                            .put("type", "text")
                            .put("text", text.take(3500))
                            .put("annotations", JSONArray().put(JSONObject()
                                .put("type", "speech_metadata")
                                .put("style", "A clear, calm, confident adult male Hindi assistant voice; natural Hindi pronunciation and steady pace.")))))))
                    .put("response_format", JSONObject().put("type", "audio"))
                    .put("generation_config", JSONObject()
                        .put("speech_config", JSONArray().put(JSONObject().put("voice", "Charon"))))
                connection.outputStream.use { it.write(request.toString().toByteArray(Charsets.UTF_8)) }
                val code = connection.responseCode
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                val response = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                if (code !in 200..299) throw IllegalStateException("Gemini TTS HTTP $code")
                val root = JSONObject(response)
                val encoded = root.optJSONObject("output_audio")?.optString("data")
                if (encoded.isNullOrBlank()) throw IllegalStateException("Gemini TTS audio missing")
                val bytes = Base64.decode(encoded, Base64.DEFAULT)
                if (bytes.size < 44 || String(bytes, 0, 4, Charsets.US_ASCII) != "RIFF")
                    throw IllegalStateException("Gemini TTS returned invalid WAV")
                val dir = File(context.cacheDir, "avy_speech").apply { mkdirs() }
                result = File.createTempFile("avy_", ".wav", dir).apply { writeBytes(bytes) }
            } catch (_: Exception) {
                result = null
            } finally { connection?.disconnect() }
            val audio = result
            android.os.Handler(android.os.Looper.getMainLooper()).post { callback(audio) }
        }.start()
    }
}
