package com.avy.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.media.AudioManager
import android.os.Build
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

class AvyAccessibilityService : AccessibilityService() {
    @Volatile private var foregroundPackage: String? = null

    // Track only the foreground package name. Window content retrieval remains disabled.
    // Financial apps are explicitly protected: AVY never dispatches gestures or global actions there.
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        foregroundPackage = pkg
    }
    override fun onInterrupt() {}

    private fun canControlForegroundApp(): Boolean {
        val pkg = foregroundPackage ?: return false
        if (pkg in PROTECTED_FINANCIAL_PACKAGES) return false
        return pkg in CONTROL_ALLOWLIST
    }

    private fun showControlBlocked() {
        Toast.makeText(this, "इस ऐप में AVY कंट्रोल सुरक्षा के लिए बंद है।", Toast.LENGTH_SHORT).show()
    }

    fun performSafeGlobalAction(action: Int) {
        if (!canControlForegroundApp()) { showControlBlocked(); return }
        performGlobalAction(action)
    }

    companion object {
        @Volatile var active: AvyAccessibilityService? = null

        // Banking/UPI apps are never controlled by AVY. Package names are best-effort
        // protection, not a guarantee that Google Pay will permit an enabled service.
        private val PROTECTED_FINANCIAL_PACKAGES = setOf(
            "com.google.android.apps.nbu.paisa.user", // Google Pay
            "com.phonepe.app",                       // PhonePe
            "net.one97.paytm",                       // Paytm
            "in.org.npci.upiapp",                    // BHIM
            "com.sbi.lotusintouch",                  // SBI YONO
            "com.csam.icici.bank.imobile",           // iMobile
            "com.snapwork.hdfc",                     // HDFC Bank
            "com.axis.mobile",                       // Axis Mobile
        )

        private val CONTROL_ALLOWLIST = setOf(
            "com.google.android.youtube",
            "com.google.android.apps.youtube.music",
            "com.android.chrome",
            "com.whatsapp",
            "com.facebook.katana",
            "com.instagram.android",
            "com.google.android.gm",
            "com.google.android.apps.maps",
            "com.spotify.music"
        )
    }

    override fun onServiceConnected() { super.onServiceConnected(); active = this }
    override fun onDestroy() { if (active === this) active = null; super.onDestroy() }

    fun swipe(up: Boolean) {
        if (!canControlForegroundApp()) { showControlBlocked(); return }
        if (Build.VERSION.SDK_INT < 24) return
        val dm = resources.displayMetrics
        val x = dm.widthPixels / 2f
        val fromY = if (up) dm.heightPixels * .78f else dm.heightPixels * .25f
        val toY = if (up) dm.heightPixels * .25f else dm.heightPixels * .78f
        val path = Path().apply { moveTo(x, fromY); lineTo(x, toY) }
        val gesture = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 450)).build()
        dispatchGesture(gesture, null, null)
    }

    fun tap(xPercent: Int, yPercent: Int) {
        if (!canControlForegroundApp()) { showControlBlocked(); return }
        if (Build.VERSION.SDK_INT < 24) return
        val dm = resources.displayMetrics
        val x = dm.widthPixels * (xPercent.coerceIn(0, 100) / 100f)
        val y = dm.heightPixels * (yPercent.coerceIn(0, 100) / 100f)
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 80)).build()
        dispatchGesture(gesture, null, null)
    }
}

object AvyPhoneActions {
    fun accessibilityEnabled(context: Context): Boolean = AvyAccessibilityService.active != null

    fun isAccessibilityCommand(raw: String): Boolean {
        val c = raw.lowercase(java.util.Locale("hi", "IN")).trim()
        return c.contains("ऊपर स्क्रॉल") || c.contains("ऊपर करो") || c.contains("scroll up") ||
            c.contains("नीचे स्क्रॉल") || c.contains("नीचे करो") || c.contains("scroll down") ||
            c.contains("वापस जाओ") || c == "बैक" || c.contains("go back") ||
            c.contains("होम स्क्रीन") || c == "होम" || c.contains("home screen") ||
            c.contains("हाल की ऐप") || c.contains("recent apps") || c.contains("नोटिफिकेशन") ||
            c.contains("सूचनाएं") || c.contains("क्विक सेटिंग") || c.startsWith("टैप ") || c.startsWith("tap ")
    }

    fun handle(context: Context, raw: String): Boolean {
        val c = raw.lowercase(java.util.Locale("hi", "IN")).trim()
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        when {
            c.contains("वॉल्यूम बढ़") || c.contains("आवाज बढ़") || c.contains("आवाज़ बढ़") || c.contains("volume up") -> {
                audio.adjustVolume(AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI); return true
            }
            c.contains("वॉल्यूम कम") || c.contains("आवाज कम") || c.contains("आवाज़ कम") || c.contains("volume down") -> {
                audio.adjustVolume(AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI); return true
            }
            c.contains("म्यूट") || c.contains("आवाज बंद") || c.contains("आवाज़ बंद") -> {
                audio.adjustVolume(AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI); return true
            }
            c.contains("अनम्यूट") || c.contains("आवाज चालू") || c.contains("आवाज़ चालू") -> {
                audio.adjustVolume(AudioManager.ADJUST_UNMUTE, AudioManager.FLAG_SHOW_UI); return true
            }
            c.contains("वॉलपेपर") || c.contains("wallpaper") -> {
                val i = Intent(Intent.ACTION_SET_WALLPAPER).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(i); return true
            }
            c.contains("ऊपर स्क्रॉल") || c.contains("ऊपर करो") || c.contains("scroll up") -> {
                AvyAccessibilityService.active?.swipe(true) ?: openAccessibilitySettings(context); return true
            }
            c.contains("नीचे स्क्रॉल") || c.contains("नीचे करो") || c.contains("scroll down") -> {
                AvyAccessibilityService.active?.swipe(false) ?: openAccessibilitySettings(context); return true
            }
            c.contains("वापस जाओ") || c == "बैक" || c.contains("go back") -> {
                val service = AvyAccessibilityService.active
                if (service == null) openAccessibilitySettings(context) else service.performSafeGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
                return true
            }
            c.contains("होम स्क्रीन") || c == "होम" || c.contains("home screen") -> {
                val service = AvyAccessibilityService.active
                if (service == null) openAccessibilitySettings(context) else service.performSafeGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
                return true
            }
            c.contains("हाल की ऐप") || c.contains("recent apps") -> {
                val service = AvyAccessibilityService.active
                if (service == null) openAccessibilitySettings(context) else service.performSafeGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS)
                return true
            }
            c.contains("नोटिफिकेशन") || c.contains("सूचनाएं") -> {
                val service = AvyAccessibilityService.active
                if (service == null) openAccessibilitySettings(context) else service.performSafeGlobalAction(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
                return true
            }
            c.contains("क्विक सेटिंग") -> {
                val service = AvyAccessibilityService.active
                if (service == null) openAccessibilitySettings(context) else service.performSafeGlobalAction(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS)
                return true
            }
            c.startsWith("टैप ") || c.startsWith("tap ") -> {
                val nums = Regex("(\\d{1,3})[ ,]+(\\d{1,3})").find(c)
                if (nums != null) AvyAccessibilityService.active?.tap(nums.groupValues[1].toInt(), nums.groupValues[2].toInt()) ?: openAccessibilitySettings(context)
                return true
            }
        }
        return false
    }

    fun openAccessibilitySettings(context: Context) {
        Toast.makeText(context, "फोन कंट्रोल के लिए AVY Accessibility अनुमति चालू करें", Toast.LENGTH_LONG).show()
        try { context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
    }
}
