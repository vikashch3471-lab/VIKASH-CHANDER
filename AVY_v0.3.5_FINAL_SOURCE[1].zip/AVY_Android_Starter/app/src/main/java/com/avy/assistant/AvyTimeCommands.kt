package com.avy.assistant

import android.content.Context
import android.content.Intent
import android.provider.AlarmClock
import java.util.Locale

/** Parses common Hindi/English alarm and timer phrases without silently guessing a time. */
object AvyTimeCommands {
    private val words = mapOf(
        "शून्य" to 0, "एक" to 1, "एकम" to 1, "दो" to 2, "तीन" to 3, "चार" to 4,
        "पांच" to 5, "पाँच" to 5, "छह" to 6, "छः" to 6, "सात" to 7, "आठ" to 8,
        "नौ" to 9, "दस" to 10, "ग्यारह" to 11, "बारह" to 12, "तेरह" to 13,
        "चौदह" to 14, "पंद्रह" to 15, "पन्द्रह" to 15, "सोलह" to 16, "सत्रह" to 17,
        "अठारह" to 18, "उन्नीस" to 19, "बीस" to 20, "इक्कीस" to 21, "बाईस" to 22,
        "तेईस" to 23, "चौबीस" to 24, "पच्चीस" to 25, "छब्बीस" to 26, "सत्ताईस" to 27,
        "अट्ठाईस" to 28, "उनतीस" to 29, "तीस" to 30, "इकतीस" to 31, "बत्तीस" to 32,
        "तैंतीस" to 33, "चौंतीस" to 34, "पैंतीस" to 35, "छत्तीस" to 36, "सैंतीस" to 37,
        "अड़तीस" to 38, "उनतालीस" to 39, "चालीस" to 40, "पैंतालीस" to 45,
        "पचास" to 50, "पचपन" to 55, "साठ" to 60
    )

    private fun normalized(raw: String): String {
        val digits = raw.map { ch -> when (ch) {
            in '०'..'९' -> ('0'.code + (ch.code - '०'.code)).toChar()
            else -> ch
        } }.joinToString("")
        return digits.lowercase(Locale.ROOT).replace("ः", "ह")
    }

    private fun numberNear(text: String, unit: Regex): Int? {
        val match = unit.find(text) ?: return null
        val before = text.substring(0, match.range.first).trim().split(Regex("\\s+")).lastOrNull().orEmpty()
        before.toIntOrNull()?.let { return it }
        return words[before]
    }

    fun setAlarm(context: Context, raw: String): String {
        val text = normalized(raw)
        val clock = Regex("(?<!\\d)(\\d{1,2})(?:\\s*[:. ]\\s*(\\d{1,2}))?\\s*(?:बजे|बजकर|am|pm)?").find(text)
        var hour = clock?.groupValues?.getOrNull(1)?.toIntOrNull()
        var minute = clock?.groupValues?.getOrNull(2)?.toIntOrNull() ?: 0
        if (hour == null) {
            val tokens = text.split(Regex("\\s+"))
            val hourToken = tokens.firstOrNull { words.containsKey(it) }
            hour = hourToken?.let { words[it] }
        }
        // Support both numeric and spoken Hindi time forms: 6:30, 6 बजकर 30,
        // साढ़े छह, सवा सात and पौने आठ.
        val spokenMinute = Regex("(?:बजकर|बज के)\\s*(\\d{1,2})").find(text)
            ?.groupValues?.getOrNull(1)?.toIntOrNull()
        if (spokenMinute != null) minute = spokenMinute
        if (text.contains("साढ़े") || text.contains("साढे")) minute = 30
        else if (text.contains("सवा")) minute = 15
        else if (text.contains("पौने")) { if (hour != null) hour -= 1; minute = 45 }
        if (hour == null || hour !in 0..23 || minute !in 0..59) return "कृपया अलार्म का समय साफ बोलें, जैसे सुबह सात बजे या शाम 6 बजकर 30 मिनट।"
        val evening = text.contains("शाम") || text.contains("रात") || text.contains("दोपहर") || Regex("\\bpm\\b").containsMatchIn(text)
        val morning = text.contains("सुबह") || Regex("\\bam\\b").containsMatchIn(text)
        if (hour in 1..11 && evening) hour += 12
        if (hour == 12 && morning) hour = 0
        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hour)
            putExtra(AlarmClock.EXTRA_MINUTES, minute)
            putExtra(AlarmClock.EXTRA_MESSAGE, "AVY अलार्म")
            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        }.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return "${if (hour < 10) "0" else ""}$hour:${if (minute < 10) "0" else ""}$minute का अलार्म खोल रहा हूँ।"
    }

    fun setTimer(context: Context, raw: String): String {
        val text = normalized(raw)
        val seconds = numberNear(text, Regex("(?:सेकंड|सेकेंड|seconds?|secs?)"))
        val minutes = numberNear(text, Regex("(?:मिनट|मिनिट|minutes?|mins?)"))
        val hours = numberNear(text, Regex("(?:घंटे|घंटा|घंटों|hours?|hrs?)"))
        val total = (seconds ?: 0) + (minutes ?: 0) * 60 + (hours ?: 0) * 3600
        if (total <= 0 || total > 7 * 24 * 3600) return "कृपया अवधि बताइए, जैसे पाँच मिनट या एक घंटा।"
        val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
            putExtra(AlarmClock.EXTRA_LENGTH, total)
            putExtra(AlarmClock.EXTRA_MESSAGE, "AVY टाइमर")
            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        }.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return "${if (hours != null) "$hours घंटे " else ""}${if (minutes != null) "$minutes मिनट " else ""}${if (seconds != null) "$seconds सेकंड" else ""}का टाइमर खोल रहा हूँ।"
    }
}
