package com.avy.assistant

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import android.util.Base64

/** Gemini text brain. API key is encrypted with an Android Keystore AES key on this device. */
object GeminiBrain {
    private const val PREFS = "avy_secure_brain"
    private const val KEY_ALIAS = "avy_gemini_key_v1"
    private const val MODEL = "gemini-3.8-flash"

    private fun secretKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder(KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true).build())
        return generator.generateKey()
    }

    fun saveApiKey(context: Context, apiKey: String) {
        require(apiKey.isNotBlank())
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, secretKey())
        val encrypted = cipher.doFinal(apiKey.trim().toByteArray(Charsets.UTF_8))
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("iv", Base64.encodeToString(cipher.iv, Base64.NO_WRAP))
            .putString("data", Base64.encodeToString(encrypted, Base64.NO_WRAP)).apply()
    }

    fun hasApiKey(context: Context): Boolean = getApiKey(context).isNotBlank()

    private fun getApiKey(context: Context): String {
        return try {
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val iv = Base64.decode(prefs.getString("iv", "") ?: "", Base64.NO_WRAP)
            val data = Base64.decode(prefs.getString("data", "") ?: "", Base64.NO_WRAP)
            if (iv.isEmpty() || data.isEmpty()) "" else {
                val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                cipher.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(128, iv))
                String(cipher.doFinal(data), Charsets.UTF_8)
            }
        } catch (_: Exception) { "" }
    }

    fun ask(context: Context, prompt: String, callback: (String) -> Unit) {
        val apiKey = getApiKey(context)
        if (apiKey.isBlank()) {
            callback("Gemini AI चालू करने के लिए AVY की सेटिंग में अपनी Gemini API Key जोड़ें।")
            return
        }
        Thread {
            var answer: String
            var connection: HttpURLConnection? = null
            try {
                // Gemini 3.8 Flash is documented on the Interactions API.
                // Use its response format instead of assuming GenerateContent candidates.
                val endpoint = "https://generativelanguage.googleapis.com/v1beta/interactions"
                connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 15000
                    readTimeout = 45000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    setRequestProperty("x-goog-api-key", apiKey)
                }
                val system = "You are AVY, a helpful multilingual Android voice assistant. Detect the language of the user's latest message and reply naturally in that same language. Keep spoken answers concise, clear and safe. If asked to translate, translate faithfully. Do not claim to perform phone actions unless the app explicitly confirms them."
                val body = JSONObject()
                    .put("model", MODEL)
                    .put("input", prompt)
                    .put("system_instruction", system)
                    .put("generation_config", JSONObject().put("max_output_tokens", 700))
                val previousId = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                    .getString("previous_interaction_id", null)
                if (!previousId.isNullOrBlank()) body.put("previous_interaction_id", previousId)
                connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val code = connection.responseCode
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                val response = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                val json = try { JSONObject(response) } catch (_: Exception) { JSONObject() }
                if (code !in 200..299) {
                    val detail = json.optJSONObject("error")?.optString("message")?.takeIf { it.isNotBlank() } ?: "HTTP $code"
                    answer = when (code) {
                        400, 403, 404 -> "Gemini API में समस्या है: $detail"
                        429 -> "Gemini की उपयोग सीमा अभी पूरी हो गई है। थोड़ी देर बाद कोशिश करें।"
                        else -> "Gemini से जवाब नहीं मिला: $detail"
                    }
                } else {
                    // Preserve the server-side conversation so follow-up questions
                    // can refer to the previous turn instead of starting from zero.
                    json.optString("id").takeIf { it.isNotBlank() }?.let { id ->
                        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                            .putString("previous_interaction_id", id).apply()
                    }
                    val output = StringBuilder()
                    // Interactions API: steps[].content[] with type=model_output.
                    val steps = json.optJSONArray("steps")
                    if (steps != null) {
                        for (i in 0 until steps.length()) {
                            val step = steps.optJSONObject(i) ?: continue
                            val content = step.optJSONArray("content") ?: continue
                            for (j in 0 until content.length()) {
                                val part = content.optJSONObject(j) ?: continue
                                if (part.optString("type") == "text") {
                                    val value = part.optString("text")
                                    if (value.isNotBlank()) output.append(value).append(' ')
                                }
                            }
                        }
                    }
                    // Tolerate output_text or legacy candidates if Google returns either shape.
                    if (output.isBlank()) output.append(json.optString("output_text", ""))
                    if (output.isBlank()) {
                        val candidates = json.optJSONArray("candidates")
                        val parts = candidates?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                        if (parts != null) for (i in 0 until parts.length()) output.append(parts.optJSONObject(i)?.optString("text", "").orEmpty()).append(' ')
                    }
                    answer = output.toString().trim().ifBlank { "Gemini से खाली जवाब मिला। फिर पूछिए।" }
                }
            } catch (e: Exception) {
                val detail = e.message?.take(180)?.replace(Regex("[\\r\\n]+"), " ").orEmpty()
                answer = "Gemini कनेक्शन त्रुटि (${e.javaClass.simpleName})${if (detail.isNotBlank()) ": $detail" else ". इंटरनेट और API Key जाँचें।"}"
            } finally {
                connection?.disconnect()
            }
            callback(answer)
        }.start()
    }

}
