package com.avy.assistant

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.BroadcastReceiver
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private lateinit var statusText: TextView
    private lateinit var heardText: TextView
    private lateinit var listenButton: Button
    private lateinit var backgroundButton: Button
    private val audioPermissionRequest = 100
    private val contactRequest = 101
    private var pendingBackgroundStart = false
    private val mainHandler = Handler(Looper.getMainLooper())
    private var activityResumed = false
    private var isListening = false
    private var isSpeaking = false
    private var autoListeningEnabled = true
    private var backgroundModeActive = false
    private var statusReceiverRegistered = false
    private val listeningStatusReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: android.content.Context?, intent: Intent?) {
            if (intent?.action != AvyListeningService.ACTION_STATUS) return
            val ok = intent.getBooleanExtra(AvyListeningService.EXTRA_OK, false)
            val message = intent.getStringExtra(AvyListeningService.EXTRA_MESSAGE).orEmpty()
            backgroundModeActive = ok
            if (::backgroundButton.isInitialized) {
                backgroundButton.isEnabled = true
                backgroundButton.text = if (ok) "■ बैकग्राउंड सुनना बंद करें" else "▶ बैकग्राउंड सुनना चालू करें"
                backgroundButton.setOnClickListener {
                    if (backgroundModeActive) {
                        stopService(Intent(this@MainActivity, AvyListeningService::class.java))
                        backgroundModeActive = false
                        backgroundButton.text = "▶ बैकग्राउंड सुनना चालू करें"
                        speak("बैकग्राउंड सुनना बंद कर दिया")
                        scheduleAutoListening(1000)
                    } else toggleBackgroundListening()
                }
            }
            if (message.isNotBlank()) {
                statusText.text = message
                if (!ok) {
                    autoListeningEnabled = true
                    scheduleAutoListening(1000)
                    Toast.makeText(this@MainActivity, message, Toast.LENGTH_LONG).show()
                }
            }
        }
    }
    private val languagePrefs by lazy { getSharedPreferences("avy_settings", MODE_PRIVATE) }
    private var selectedLocale: String = "hi-IN"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        selectedLocale = languagePrefs.getString("speech_locale", "hi-IN") ?: "hi-IN"
        backgroundModeActive = languagePrefs.getBoolean("background_listening_active", false)
        buildScreen()
        val statusFilter = IntentFilter(AvyListeningService.ACTION_STATUS)
        ContextCompat.registerReceiver(this, listeningStatusReceiver, statusFilter, ContextCompat.RECEIVER_NOT_EXPORTED)
        statusReceiverRegistered = true
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
            speechRecognizer?.setRecognitionListener(listener)
        } else {
            statusText.text = "इस फोन पर वॉइस रिकग्निशन उपलब्ध नहीं है।"
        }
        greet()
        requestMicrophoneAndStartIfAllowed()
    }

    override fun onResume() {
        super.onResume()
        activityResumed = true
        if (!backgroundModeActive && ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            scheduleAutoListening(500)
        }
    }

    override fun onPause() {
        activityResumed = false
        mainHandler.removeCallbacksAndMessages(null)
        try { speechRecognizer?.cancel() } catch (_: Exception) {}
        isListening = false
        super.onPause()
    }

    private fun requestMicrophoneAndStartIfAllowed() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), audioPermissionRequest)
        } else {
            if (!backgroundModeActive) scheduleAutoListening(700)
        }
    }

    private fun scheduleAutoListening(delayMs: Long = 700) {
        if (!autoListeningEnabled || backgroundModeActive || !activityResumed || isListening || isSpeaking) return
        mainHandler.removeCallbacks(autoListenRunnable)
        mainHandler.postDelayed(autoListenRunnable, delayMs)
    }

    private val autoListenRunnable = Runnable {
        if (autoListeningEnabled && !backgroundModeActive && activityResumed && !isListening && !isSpeaking) startListening()
    }

    private lateinit var rootLayout: LinearLayout
    private lateinit var screenContent: LinearLayout
    private var activeTab = "home"

    private fun buildScreen() {
        val bg = android.graphics.Color.rgb(2, 8, 18)
        val panel = android.graphics.Color.rgb(5, 22, 39)
        val cyan = android.graphics.Color.rgb(0, 205, 255)
        val white = android.graphics.Color.WHITE
        val muted = android.graphics.Color.rgb(155, 190, 215)
        fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

        rootLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        screenContent = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(12), dp(16), dp(18)) }
        val scroll = android.widget.ScrollView(this).apply { isFillViewport = true; addView(screenContent) }
        rootLayout.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            setPadding(dp(5), dp(7), dp(5), dp(7))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(android.graphics.Color.rgb(4, 17, 31)); cornerRadii = floatArrayOf(dp(18).toFloat(),dp(18).toFloat(),dp(18).toFloat(),dp(18).toFloat(),0f,0f,0f,0f)
                setStroke(dp(1), android.graphics.Color.rgb(0, 105, 160))
            }
        }
        fun navButton(label: String, tab: String) = Button(this).apply {
            text = label; isAllCaps = false; textSize = 12f; setTextColor(if (activeTab == tab) cyan else muted)
            setBackgroundColor(android.graphics.Color.TRANSPARENT)
            setOnClickListener { showTab(tab) }
        }
        listOf("⌂\nहोम" to "home", "▤\nचैट" to "chat", "✣\nटूल्स" to "tools", "⚙\nसेटिंग्स" to "settings").forEach { (label, tab) ->
            nav.addView(navButton(label, tab), LinearLayout.LayoutParams(0, dp(58), 1f))
        }
        rootLayout.addView(nav, LinearLayout.LayoutParams(-1, -2))
        setContentView(rootLayout)
        showTab("home")
    }

    private fun showTab(tab: String) {
        activeTab = tab
        screenContent.removeAllViews()
        val bg = android.graphics.Color.rgb(2, 8, 18)
        val panel = android.graphics.Color.rgb(5, 22, 39)
        val cyan = android.graphics.Color.rgb(0, 205, 255)
        val white = android.graphics.Color.WHITE
        val muted = android.graphics.Color.rgb(155, 190, 215)
        fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
        fun text(value: String, size: Float, color: Int = white, bold: Boolean = false, center: Boolean = false) = TextView(this).apply {
            text = value; textSize = size; setTextColor(color); if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
            if (center) gravity = Gravity.CENTER
        }
        fun heading(value: String) { screenContent.addView(text(value, 20f, cyan, true).apply { setPadding(0, dp(18), 0, dp(10)) }) }
        fun card(title: String, subtitle: String, action: () -> Unit) {
            val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(15), dp(13), dp(15), dp(13))
                background = android.graphics.drawable.GradientDrawable().apply { setColor(panel); cornerRadius = dp(17).toFloat(); setStroke(dp(1), android.graphics.Color.rgb(0, 135, 195)) }
                setOnClickListener { action() } }
            box.addView(text(title, 16f, white, true)); box.addView(text(subtitle, 12f, muted).apply { setPadding(0, dp(4), 0, 0) })
            screenContent.addView(box, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        }
        fun actionButton(label: String, action: () -> Unit) {
            val b = Button(this).apply { text = label; isAllCaps = false; textSize = 15f; setOnClickListener { action() } }
            screenContent.addView(b, LinearLayout.LayoutParams(-1, dp(49)).apply { bottomMargin = dp(8) })
        }
        when (tab) {
            "home" -> {
                val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                top.addView(ImageView(this).apply { setImageResource(R.drawable.avy_logo); scaleType = ImageView.ScaleType.FIT_CENTER }, LinearLayout.LayoutParams(dp(58), dp(58)))
                top.addView(text("AVY", 29f, cyan, true).apply { setPadding(dp(10), 0, 0, 0) }, LinearLayout.LayoutParams(0, -2, 1f))
                top.addView(text("🔔", 22f, white).apply { setOnClickListener { Toast.makeText(this@MainActivity, "अभी कोई नई सूचना नहीं है", Toast.LENGTH_SHORT).show() } })
                screenContent.addView(top)
                screenContent.addView(text("मैं AVY हूँ", 23f, white, true, true).apply { setPadding(0, dp(15), 0, dp(4)) })
                screenContent.addView(text("बोलिए, मैं आपकी क्या मदद करूँ?", 15f, muted, false, true).apply { setPadding(0, 0, 0, dp(15)) })
                val robot = ImageView(this).apply { setImageResource(R.drawable.avy_logo); scaleType = ImageView.ScaleType.FIT_CENTER }
                screenContent.addView(robot, LinearLayout.LayoutParams(dp(190), dp(190)).apply { gravity = Gravity.CENTER })
                statusText = text("AVY तैयार है • आप बोलकर आदेश दे सकते हैं", 13f, cyan, false, true).apply { setPadding(0, dp(8), 0, dp(4)) }
                screenContent.addView(statusText)
                heardText = text("आपकी बात यहाँ दिखाई देगी", 14f, white, false, true).apply { setPadding(0, dp(4), 0, dp(12)) }
                screenContent.addView(heardText)
                listenButton = Button(this).apply { text = "🎙  AVY से बात करें"; textSize = 19f; isAllCaps = false; setOnClickListener { autoListeningEnabled = true; startListening() } }
                screenContent.addView(listenButton, LinearLayout.LayoutParams(-1, dp(60)).apply { bottomMargin = dp(8) })
                backgroundButton = Button(this).apply {
                    text = if (backgroundModeActive) "■ बैकग्राउंड सुनना बंद करें" else "▶ बैकग्राउंड सुनना चालू करें"
                    isAllCaps = false; setOnClickListener { toggleBackgroundListening() }
                }
                screenContent.addView(backgroundButton, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(12) })
                heading("त्वरित काम")
                card("📞 कॉल करें", "किसी संपर्क को बोलकर कॉल करें", { startListening() })
                card("♫ संगीत चलाएँ", "अपना म्यूजिक ऐप खोलें", { openMusic() })
                card("⌕ इंटरनेट पर खोजें", "Google पर बोलकर खोजें", { openUrl("https://www.google.com", "गूगल खोल रहा हूँ") })
                card("▦ ऐप खोलें", "YouTube, WhatsApp, Chrome आदि", { speak("कहें: यूट्यूब खोलो या व्हाट्सऐप खोलो") })
            }
            "chat" -> {
                heading("AVY • Gemini AI Chat")
                screenContent.addView(text("अपने सवाल लिखें या माइक से बोलें। जवाब Gemini से आएगा।", 14f, muted).apply { setPadding(0, 0, 0, dp(14)) })
                heardText = text("नमस्ते! मैं AVY हूँ। मुझसे कुछ भी पूछिए।", 15f, white).apply { setPadding(dp(12), dp(14), dp(12), dp(14)); background = android.graphics.drawable.GradientDrawable().apply { setColor(panel); cornerRadius = dp(14).toFloat() } }
                screenContent.addView(heardText, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
                val input = EditText(this).apply { hint = "अपना सवाल यहाँ लिखें…"; setTextColor(white); setHintTextColor(muted); minLines = 3; gravity = Gravity.TOP; setPadding(dp(12), dp(10), dp(12), dp(10)); background = android.graphics.drawable.GradientDrawable().apply { setColor(panel); cornerRadius = dp(13).toFloat(); setStroke(dp(1), cyan) } }
                screenContent.addView(input, LinearLayout.LayoutParams(-1, dp(110)).apply { bottomMargin = dp(10) })
                actionButton("➤ Gemini को भेजें") { val q = input.text.toString().trim(); if (q.isNotBlank()) { heardText.text = "आप: $q\n\nGemini सोच रहा है…"; GeminiBrain.ask(this, q) { a -> runOnUiThread { heardText.text = "आप: $q\n\nAVY: $a" } } } }
                actionButton("🎙 बोलकर पूछें") { startListening() }
                if (!GeminiBrain.hasApiKey(this)) actionButton("Gemini API Key जोड़ें") { showGeminiKeyDialog(Button(this)) }
            }
            "tools" -> {
                heading("AVY – सभी फीचर्स")
                val toolItems: List<Triple<String, String, () -> Unit>> = listOf(
                    Triple("🧠 AI चैट", "Gemini बातचीत", { showTab("chat") }),
                    Triple("🎙 वॉइस सिस्टम", "सुनना और बोलना", { startListening() }),
                    Triple("📞 फोन कंट्रोल", "स्क्रॉल, Home, Back", { AvyPhoneActions.openAccessibilitySettings(this) }),
                    Triple("▦ ऐप मैनेजर", "ऐप बोलकर खोलें", { speak("कहें: यूट्यूब खोलो, व्हाट्सऐप खोलो या क्रोम खोलो") }),
                    Triple("🌐 इंटरनेट टूल्स", "वेब और मैप खोजें", { openUrl("https://www.google.com", "गूगल खोल रहा हूँ") }),
                    Triple("♫ मीडिया", "म्यूजिक और वीडियो", { openMusic() }),
                    Triple("⏱ प्रोडक्टिविटी", "अलार्म और टाइमर", { speak("कहें: पाँच मिनट का टाइमर लगाओ या सात बजे अलार्म लगाओ") }),
                    Triple("✣ कस्टम कमांड", "अपनी आवाज़ से काम", { startListening() })
                )
                toolItems.chunked(2).forEach { pair ->
                    val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                    pair.forEachIndexed { index, item ->
                        val tile = LinearLayout(this).apply {
                            orientation = LinearLayout.VERTICAL
                            gravity = Gravity.CENTER_VERTICAL
                            setPadding(dp(13), dp(15), dp(13), dp(15))
                            background = android.graphics.drawable.GradientDrawable().apply {
                                setColor(panel); cornerRadius = dp(17).toFloat()
                                setStroke(dp(1), android.graphics.Color.rgb(0, 135, 195))
                            }
                            setOnClickListener { item.third.invoke() }
                        }
                        tile.addView(text(item.first, 16f, white, true))
                        tile.addView(text(item.second, 12f, muted).apply { setPadding(0, dp(6), 0, 0) })
                        row.addView(tile, LinearLayout.LayoutParams(0, dp(104), 1f).apply {
                            if (index == 0) rightMargin = dp(6) else leftMargin = dp(6)
                        })
                    }
                    screenContent.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
                }
            }
            "settings" -> {
                heading("⚙ AVY सेटिंग्स")
                card("🛡 अनुमतियाँ (Permissions)", "माइक्रोफोन और फोन कंट्रोल अनुमति", { AlertDialog.Builder(this).setTitle("अनुमतियाँ").setMessage("माइक्रोफोन: ${if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) "अनुमति मिली हुई है" else "अनुमति बाकी है"}\n\nफोन कंट्रोल के लिए Android Accessibility सेवा चालू करें।").setPositiveButton("Accessibility खोलें") { _, _ -> AvyPhoneActions.openAccessibilitySettings(this) }.setNegativeButton("ठीक है", null).show() })
                card("🔐 सुरक्षा और गोपनीयता", "API Key फोन में Android Keystore से सुरक्षित", { AlertDialog.Builder(this).setTitle("AVY सुरक्षा").setMessage("AVY SMS या Notifications पढ़ने की अनुमति नहीं माँगती। Play Protect चालू रखें।").setPositiveButton("ठीक है", null).show() })
                card("🏦 Banking Safe Mode", "UPI और बैंकिंग ऐप्स में AVY Automation निष्क्रिय", { AlertDialog.Builder(this).setTitle("बैंकिंग सुरक्षा").setMessage("AVY Google Pay, PhonePe, Paytm और सूचीबद्ध बैंकिंग ऐप्स में स्क्रॉल, टैप या नेविगेशन ऑटोमेशन नहीं चलाती। सामान्य ऐप कंट्रोल केवल चुने हुए ऐप्स में उपलब्ध है।\n\nमहत्वपूर्ण: Google Pay कुछ फोन पर Accessibility Service चालू होने मात्र से पेमेंट रोक सकता है। ऐसी स्थिति में पेमेंट से पहले Android Settings में AVY Accessibility को स्वयं बंद करना होगा। AVY इसे अपने आप बंद नहीं कर सकती।").setPositiveButton("Accessibility सेटिंग खोलें") { _, _ -> AvyPhoneActions.openAccessibilitySettings(this) }.setNegativeButton("ठीक है", null).show() })
                card("🌐 आवाज़ और भाषा", "हिंदी, English और उपलब्ध भाषाएँ", { showLanguagePicker(Button(this)) })
                card("🧠 AI मॉडल", if (GeminiBrain.hasApiKey(this)) "Gemini API Key सुरक्षित सेव है" else "Gemini API Key जोड़ें", { showGeminiKeyDialog(Button(this)) })
                card("🔌 Gemini कनेक्शन टेस्ट", "वास्तविक API अनुरोध भेजकर जवाब जाँचें", { testGeminiConnection() })
                card("🎨 इंटरफेस (थीम)", "नीला Neon Dark इंटरफेस", { Toast.makeText(this, "Neon Dark थीम सक्रिय है", Toast.LENGTH_SHORT).show() })
                card("⚙ एडवांस सेटिंग्स", "बैकग्राउंड मोड और सिस्टम सेटिंग्स", { startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)) })
                card("🔄 अपडेट", "नया संस्करण और सुधार", { checkForUpdates() })
                card("ⓘ ऐप के बारे में", "AVY Personal AI Assistant • v0.3.5", { AlertDialog.Builder(this).setTitle("AVY AI").setMessage("आपका व्यक्तिगत AI स्मार्ट असिस्टेंट।\n\nDesigned & developed with ChatGPT AI assistance.\n\nAVY स्वतंत्र प्रोजेक्ट है; यह OpenAI/ChatGPT का आधिकारिक ऐप नहीं है। AI जवाब Gemini API से आते हैं। कुछ फीचर फोन की अनुमति और डिवाइस सपोर्ट पर निर्भर हैं।").setPositiveButton("ठीक है", null).show() })
            }
        }
    }

    private fun languageLabel(tag: String): String = LANGUAGE_OPTIONS.firstOrNull { it.second == tag }?.first ?: tag

    private fun showLanguagePicker(button: Button) {
        val labels = LANGUAGE_OPTIONS.map { it.first }.toTypedArray()
        val selectedIndex = LANGUAGE_OPTIONS.indexOfFirst { it.second == selectedLocale }.coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("AVY की बातचीत की भाषा")
            .setSingleChoiceItems(labels, selectedIndex) { dialog, which ->
                selectedLocale = LANGUAGE_OPTIONS[which].second
                languagePrefs.edit().putString("speech_locale", selectedLocale).apply()
                button.text = "🌐 भाषा चुनें: ${languageLabel(selectedLocale)}"
                try { tts?.setLanguage(Locale.forLanguageTag(selectedLocale)) } catch (_: Exception) {}
                dialog.dismiss()
                speak("भाषा बदल दी गई है: ${languageLabel(selectedLocale)}। यदि इस फोन में यह भाषा उपलब्ध नहीं है तो वॉइस सेवा काम नहीं कर सकती।")
            }
            .setNegativeButton("रद्द", null)
            .show()
    }

    companion object {
        // Speech recognition and TTS availability depends on the Android speech provider and installed voices.
        private val LANGUAGE_OPTIONS = listOf(
            "हिंदी" to "hi-IN", "English (India)" to "en-IN", "English (US)" to "en-US",
            "ਪੰਜਾਬੀ" to "pa-IN", "हरियाणवी (हिंदी आधारित)" to "hi-IN", "ગુજરાતી" to "gu-IN",
            "मराठी" to "mr-IN", "বাংলা" to "bn-IN", "অসমীয়া" to "as-IN", "தமிழ்" to "ta-IN",
            "తెలుగు" to "te-IN", "ಕನ್ನಡ" to "kn-IN", "മലയാളം" to "ml-IN", "ଓଡ଼ିଆ" to "or-IN",
            "اردو" to "ur-IN", "नेपाली" to "ne-NP", "संस्कृत" to "sa-IN", "डोगरी" to "doi-IN",
            "कोंकणी" to "kok-IN", "मैथिली" to "mai-IN", "बोडो" to "brx-IN", "मणिपुरी" to "mni-IN",
            "कश्मीरी" to "ks-IN", "संथाली" to "sat-IN", "भोजपुरी (हिंदी आधारित)" to "hi-IN",
            "Español" to "es-ES", "Français" to "fr-FR", "Deutsch" to "de-DE", "Italiano" to "it-IT",
            "Português" to "pt-PT", "العربية" to "ar-SA", "فارسی" to "fa-IR", "Türkçe" to "tr-TR",
            "中文 (普通话)" to "zh-CN", "日本語" to "ja-JP", "한국어" to "ko-KR", "ไทย" to "th-TH",
            "Bahasa Indonesia" to "id-ID", "Tiếng Việt" to "vi-VN", "Русский" to "ru-RU",
            "Nederlands" to "nl-NL", "Polski" to "pl-PL", "Українська" to "uk-UA",
            "Kiswahili" to "sw-KE", "አማርኛ" to "am-ET", "Hausa" to "ha-NG", "Yorùbá" to "yo-NG"
        )
    }

    private fun toggleBackgroundListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            pendingBackgroundStart = true
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), audioPermissionRequest)
            return
        }
        // Android 13+ पर notification permission न मिलने से foreground service
        // शुरू करना अपने-आप ब्लॉक नहीं होता; इसलिए इसे microphone permission की
        // तरह अनिवार्य न मानें। वास्तविक स्थिति service से broadcast होगी।
        val intent = Intent(this, AvyListeningService::class.java)
        try {
            autoListeningEnabled = false
            mainHandler.removeCallbacks(autoListenRunnable)
            try { speechRecognizer?.cancel() } catch (_: Exception) {}
            isListening = false
            ContextCompat.startForegroundService(this, intent)
            backgroundButton.text = "… बैकग्राउंड सर्विस शुरू हो रही है"
            backgroundButton.isEnabled = false
        } catch (e: Exception) {
            autoListeningEnabled = true
            backgroundButton.isEnabled = true
            val reason = e.localizedMessage ?: e.javaClass.simpleName
            statusText.text = "बैकग्राउंड मोड शुरू नहीं हुआ: $reason"
            Toast.makeText(this, "AVY सर्विस शुरू नहीं हुई: $reason", Toast.LENGTH_LONG).show()
            Log.e("AVY", "Unable to start microphone foreground service", e)
            scheduleAutoListening(1000)
        }
    }

    private fun startListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), audioPermissionRequest)
            return
        }
        val recognizer = speechRecognizer ?: return
        if (isListening || !activityResumed) return
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, selectedLocale)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, selectedLocale)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "एवी सुन रहा है...")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        statusText.text = "सुन रहा हूँ... अब सीधे बोलिए।"
        listenButton.isEnabled = false
        try {
            isListening = true
            recognizer.startListening(intent)
        } catch (e: Exception) {
            isListening = false
            listenButton.isEnabled = true
            statusText.text = "वॉइस शुरू नहीं हो पाई। फिर कोशिश कर रहा हूँ।"
            scheduleAutoListening(1800)
        }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) { statusText.text = "बोलिए, मैं सुन रहा हूँ..." }
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() { statusText.text = "समझ रहा हूँ..." }
        override fun onError(error: Int) {
            isListening = false
            listenButton.isEnabled = true
            statusText.text = "फिर से सुनने की तैयारी..."
            scheduleAutoListening(1400)
        }
        override fun onResults(results: Bundle?) {
            isListening = false
            listenButton.isEnabled = true
            val words = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            val command = words?.firstOrNull().orEmpty()
            if (command.isNotBlank()) {
                heardText.text = "आपने कहा: $command"
                handleCommand(command)
            } else scheduleAutoListening(500)
        }
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun handleCommand(raw: String) {
        if (AvyPhoneActions.isAccessibilityCommand(raw) && !AvyPhoneActions.accessibilityEnabled(this)) {
            AvyPhoneActions.openAccessibilitySettings(this)
            speak("फोन कंट्रोल के लिए AVY की Accessibility अनुमति चालू करें।")
            return
        }
        if (AvyPhoneActions.handle(this, raw)) {
            speak("जी, कमांड पूरी कर रहा हूँ।")
            return
        }
        val command = raw.lowercase(Locale("hi", "IN")).trim()
        when {
            command.contains("टाइमर") || command.contains("timer") ->
                setTimer(raw)
            command.contains("समय") || command == "टाइम" || command == "time" ->
                speak("अभी समय है " + SimpleDateFormat("h:mm a", Locale("hi", "IN")).format(Date()))
            command.contains("यूट्यूब") || command.contains("youtube") ->
                openUrl("https://www.youtube.com", "यूट्यूब खोल रहा हूँ")
            command.contains("गूगल") || command.contains("सर्च") || command.contains("खोजो") ->
                searchGoogle(command, raw)
            command.contains("अलार्म") || command.contains("alarm") ->
                setAlarm(raw)
            command.contains("कॉल") || command.contains("फोन लगाओ") ->
                makeCall(raw)
            command.contains("व्हाट्सएप") || command.contains("whatsapp") ->
                launchApp("com.whatsapp", "व्हाट्सऐप")
            command.contains("मैप") || command.contains("रास्ता") ->
                openUrl("https://maps.google.com", "मैप खोल रहा हूँ")
            command.contains("गाना") || command.contains("म्यूजिक") || command.contains("संगीत") ->
                openMusic()
            command.contains("क्रोम") || command.contains("ब्राउज़र") ->
                launchApp("com.android.chrome", "ब्राउज़र")
            command.contains("सेटिंग") ->
                startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
            command.contains("सुनना बंद") || command.contains("एवी बंद") || command.contains("रुको एवी") -> {
                autoListeningEnabled = false
                mainHandler.removeCallbacks(autoListenRunnable)
                speak("ठीक है, मैंने सुनना बंद कर दिया है। फिर शुरू करने के लिए अभी सुनें दबाएँ।")
            }
            command.contains("बंद") || command.contains("रुको") -> speak("ठीक है।")
            else -> askGemini(raw)
        }
    }


    private fun showGeminiKeyDialog(button: Button) {
        val input = EditText(this).apply {
            hint = "Gemini API Key यहाँ पेस्ट करें"
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine(true)
        }
        AlertDialog.Builder(this)
            .setTitle("AVY Gemini AI Brain")
            .setMessage("अपनी Google AI Studio API Key डालें। यह इस फोन के Android Keystore से एन्क्रिप्ट होकर सेव होगी। इसे किसी को न भेजें। यह अभी व्यक्तिगत परीक्षण के लिए है; ऐप दूसरों को देने से पहले सुरक्षित Backend जरूरी होगा।")
            .setView(input)
            .setPositiveButton("सुरक्षित करके जोड़ें") { _, _ ->
                val key = input.text?.toString()?.trim().orEmpty()
                if (key.length < 20) Toast.makeText(this, "API Key सही से पेस्ट करें।", Toast.LENGTH_LONG).show()
                else try {
                    GeminiBrain.saveApiKey(this, key)
                    button.text = "🧠 Gemini AI सेटिंग (कनेक्टेड)"
                    Toast.makeText(this, "Gemini Key इस फोन में सुरक्षित सेव हो गई। अब AVY से सवाल पूछें।", Toast.LENGTH_LONG).show()
                } catch (_: Exception) { Toast.makeText(this, "Key सुरक्षित सेव नहीं हो सकी।", Toast.LENGTH_LONG).show() }
            }
            .setNegativeButton("रद्द", null)
            .show()
    }


    private fun testGeminiConnection() {
        if (!GeminiBrain.hasApiKey(this)) {
            AlertDialog.Builder(this)
                .setTitle("Gemini Key नहीं मिली")
                .setMessage("पहले AI मॉडल विकल्प में अपनी Gemini API Key सुरक्षित रूप से जोड़ें। API Key चैट में न भेजें।")
                .setPositiveButton("ठीक है", null)
                .show()
            return
        }
        Toast.makeText(this, "Gemini से वास्तविक कनेक्शन जाँचा जा रहा है…", Toast.LENGTH_SHORT).show()
        GeminiBrain.ask(this, "Reply with exactly: AVY Gemini connection successful") { answer ->
            runOnUiThread {
                AlertDialog.Builder(this)
                    .setTitle(if (answer.contains("AVY Gemini connection successful", ignoreCase = true)) "Gemini कनेक्शन सफल" else "Gemini कनेक्शन जाँच")
                    .setMessage(answer)
                    .setPositiveButton("ठीक है", null)
                    .show()
            }
        }
    }

    private fun askGemini(prompt: String) {
        statusText.text = "Gemini AI सोच रहा है..."
        listenButton.isEnabled = false
        GeminiBrain.ask(this, prompt) { answer ->
            runOnUiThread {
                listenButton.isEnabled = true
                heardText.text = "आपने कहा: $prompt"
                speak(answer)
            }
        }
    }

    private fun searchGoogle(command: String, original: String) {
        val cleaned = original.replace(Regex("(?i)गूगल पर|गूगल में|सर्च करो|खोजो|खोज कर|सर्च"), "").trim()
        val query = if (cleaned.isBlank()) original else cleaned
        openUrl("https://www.google.com/search?q=" + Uri.encode(query), "गूगल पर खोज रहा हूँ: $query")
    }

    private fun openUrl(url: String, message: String) {
        speak(message)
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        catch (_: Exception) { speak("यह लिंक खोलने में परेशानी हुई।") }
    }

    private fun launchApp(packageName: String, label: String) {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) {
            speak("$label खोल रहा हूँ")
            startActivity(launch)
        } else speak("$label ऐप इस फोन में नहीं मिला।")
    }

    private fun makeCall(raw: String) {
        val number = Regex("[+]?\\d[\\d\\s-]{7,}").find(raw)?.value?.replace(Regex("[\\s-]"), "")
        if (number != null) {
            speak("$number के लिए डायलर खोल रहा हूँ")
            startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")))
        } else {
            speak("कॉन्टैक्ट चुनने के लिए संपर्क सूची खोल रहा हूँ")
            val pick = Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI)
            startActivityForResult(pick, contactRequest)
        }
    }

    @Deprecated("Legacy contact picker callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == contactRequest && resultCode == RESULT_OK && data?.data != null) {
            val cursor = contentResolver.query(data.data!!,
                arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER), null, null, null)
            cursor?.use {
                if (it.moveToFirst()) {
                    val number = it.getString(0)
                    startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")))
                }
            }
        }
    }

    private fun setAlarm(raw: String) {
        try {
            speak(AvyTimeCommands.setAlarm(this, raw))
        } catch (_: Exception) {
            speak("इस फोन में अलार्म ऐप नहीं खुल पाया।")
        }
    }

    private fun setTimer(raw: String) {
        try {
            speak(AvyTimeCommands.setTimer(this, raw))
        } catch (_: Exception) {
            speak("इस फोन में टाइमर ऐप नहीं खुल पाया।")
        }
    }

    private fun openMusic() {
        val candidates = listOf("com.spotify.music", "com.google.android.apps.youtube.music",
            "com.google.android.music", "com.sec.android.app.music")
        val pkg = candidates.firstOrNull { packageManager.getLaunchIntentForPackage(it) != null }
        if (pkg != null) launchApp(pkg, "म्यूजिक ऐप")
        else openUrl("https://music.youtube.com", "म्यूजिक खोल रहा हूँ")
    }


    // अपनी HTTPS release-manifest URL यहाँ डालें। Manifest में versionCode,
    // versionName, apkUrl और notes फ़ील्ड होने चाहिए।
    private val updateManifestUrl = "https://YOUR-DOMAIN.example/avy/update.json"

    private fun checkForUpdates() {
        if (updateManifestUrl.contains("YOUR-DOMAIN.example")) {
            AlertDialog.Builder(this)
                .setTitle("अपडेट सुविधा अभी तैयार नहीं")
                .setMessage("AVY का अपडेट सर्वर अभी कॉन्फ़िगर नहीं है। इस विकल्प से फिलहाल अपडेट डाउनलोड नहीं होगा।")
                .setPositiveButton("ठीक है", null)
                .show()
            return
        }
        statusText.text = "AVY के अपडेट जाँच रहा हूँ..."
        Thread {
            var resultMessage = "अभी कोई नया अपडेट उपलब्ध नहीं है।"
            var updateInfo: JSONObject? = null
            var failure: String? = null
            try {
                val connection = (URL(updateManifestUrl).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 8000
                    readTimeout = 8000
                    requestMethod = "GET"
                }
                try {
                    if (!updateManifestUrl.startsWith("https://")) {
                        throw IllegalStateException("अपडेट सर्वर का लिंक HTTPS होना चाहिए।")
                    }
                    val body = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                    val json = JSONObject(body)
                    val latestCode = json.optInt("versionCode", 0)
                    val currentCode = packageManager.getPackageInfo(packageName, 0).versionCode
                    if (latestCode > currentCode) {
                        val apkUrl = json.optString("apkUrl", "")
                        if (!apkUrl.startsWith("https://")) {
                            throw IllegalStateException("अपडेट APK का सुरक्षित HTTPS लिंक उपलब्ध नहीं है।")
                        }
                        updateInfo = json
                    }
                } finally {
                    connection.disconnect()
                }
            } catch (e: Exception) {
                failure = e.message ?: "अपडेट जाँच नहीं हो सकी।"
            }
            runOnUiThread {
                val info = updateInfo
                when {
                    failure != null -> {
                        statusText.text = "अपडेट जाँच में समस्या आई।"
                        Toast.makeText(this, failure, Toast.LENGTH_LONG).show()
                    }
                    info != null -> {
                        val version = info.optString("versionName", "नया संस्करण")
                        val notes = info.optString("notes", "नई सुविधाएँ और सुधार")
                        AlertDialog.Builder(this)
                            .setTitle("AVY का अपडेट उपलब्ध है")
                            .setMessage("$version\n\n$notes\n\nडाउनलोड पेज खोलें?")
                            .setNegativeButton("बाद में", null)
                            .setPositiveButton("डाउनलोड") { _, _ ->
                                val link = info.optString("apkUrl")
                                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link)))
                            }
                            .show()
                        statusText.text = "नया अपडेट उपलब्ध है।"
                        speak("एवी का नया अपडेट उपलब्ध है।")
                    }
                    else -> {
                        statusText.text = resultMessage
                        speak(resultMessage)
                    }
                }
            }
        }.start()
    }

    private fun greet() { statusText.post { statusText.text = "AVY तैयार है। अब सीधे बोलिए, बटन दबाने की जरूरत नहीं है।" } }

    private fun speak(message: String) {
        statusText.text = message
        isSpeaking = true
        val result = tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "AVY_SPEECH")
        if (result == TextToSpeech.ERROR || tts == null) {
            isSpeaking = false
            scheduleAutoListening(900)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) { isSpeaking = true }
                override fun onDone(utteranceId: String?) {
                    isSpeaking = false
                    runOnUiThread { scheduleAutoListening(650) }
                }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    isSpeaking = false
                    runOnUiThread { scheduleAutoListening(900) }
                }
            })
            val result = tts?.setLanguage(Locale.forLanguageTag(selectedLocale))
            tts?.setPitch(0.78f)
            tts?.setSpeechRate(0.92f)
            val maleVoice = tts?.voices?.firstOrNull {
                it.locale.language == "hi" && it.name.contains("male", ignoreCase = true)
            }
            if (maleVoice != null) tts?.voice = maleVoice
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                statusText.post { statusText.text = "हिंदी आवाज़ के लिए फोन में हिंदी TTS भाषा इंस्टॉल करें।" }
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == audioPermissionRequest && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            if (pendingBackgroundStart) {
                pendingBackgroundStart = false
                toggleBackgroundListening()
            } else {
                autoListeningEnabled = true
                scheduleAutoListening(500)
            }
        } else if (requestCode == audioPermissionRequest) {
            pendingBackgroundStart = false
            Toast.makeText(this, "वॉइस कमांड के लिए माइक्रोफोन अनुमति जरूरी है।", Toast.LENGTH_LONG).show()
        } else if (requestCode == 102 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            toggleBackgroundListening()
        } else if (requestCode == 102) {
            Toast.makeText(this, "बैकग्राउंड नोटिफिकेशन अनुमति जरूरी है।", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        mainHandler.removeCallbacksAndMessages(null)
        if (statusReceiverRegistered) {
            try { unregisterReceiver(listeningStatusReceiver) } catch (_: Exception) {}
            statusReceiverRegistered = false
        }
        speechRecognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
