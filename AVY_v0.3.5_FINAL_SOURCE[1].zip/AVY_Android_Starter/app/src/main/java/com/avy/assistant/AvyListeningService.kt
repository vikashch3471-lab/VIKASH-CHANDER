package com.avy.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import android.content.pm.PackageManager
import android.Manifest
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.widget.Toast
import java.util.Locale

/**
 * Opt-in, visible foreground microphone service. Recognition is restarted after
 * each phrase; Android/device speech providers may still stop or throttle it.
 */
class AvyListeningService : Service(), TextToSpeech.OnInitListener {
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private val handler = Handler(Looper.getMainLooper())
    private var isStopping = false
    private var isSpeaking = false
    private var isProcessingCommand = false
    private var recognizerReady = false
    private var recognizerErrorCount = 0
    private var pendingSpeech: String? = null
    private val startupTimeout = Runnable {
        if (!isStopping && !recognizerReady) {
            Log.e(TAG, "SpeechRecognizer did not become ready within startup timeout")
            sendStatus(false, "वॉइस सेवा शुरू हुई, लेकिन फोन का Speech Recognizer जवाब नहीं दे रहा। Google ऐप/स्पीच सर्विस और इंटरनेट जाँचें, फिर दोबारा शुरू करें।")
            stopListeningService()
        }
    }
    private val selectedLocale: String by lazy { getSharedPreferences("avy_settings", MODE_PRIVATE).getString("speech_locale", "hi-IN") ?: "hi-IN" }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Log.e(TAG, "RECORD_AUDIO permission missing when AvyListeningService started")
            sendStatus(false, "माइक्रोफोन अनुमति नहीं मिली। AVY को अनुमति देकर फिर शुरू करें।")
            stopSelf()
            return
        }
        val openApp = PendingIntent.getActivity(
            this, 4108, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this, 4109, Intent(this, AvyListeningService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("AVY वॉइस सेवा")
            .setContentText("बैकग्राउंड सुनना चालू है। AVY खोलने के लिए टैप करें।")
            .setContentIntent(openApp)
            .addAction(android.R.drawable.ic_media_pause, "सुनना बंद करें", stopIntent)
            .setOngoing(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .build()
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
            // Do not report success yet: SpeechRecognizer still has to initialize.
        } catch (e: SecurityException) {
            Log.e(TAG, "Foreground microphone service permission failure", e)
            sendStatus(false, "Android ने माइक्रोफोन सर्विस शुरू करने से रोका: ${e.message ?: "अनुमति जाँचें"}")
            stopSelf()
            return
        } catch (e: RuntimeException) {
            Log.e(TAG, "Foreground service failed to start", e)
            sendStatus(false, "बैकग्राउंड सर्विस शुरू नहीं हुई: ${e.message ?: "सिस्टम त्रुटि"}")
            stopSelf()
            return
        }
        tts = TextToSpeech(this, this)
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            try {
                recognizer = SpeechRecognizer.createSpeechRecognizer(this).also {
                    it.setRecognitionListener(recognitionListener)
                }
                handler.removeCallbacks(startupTimeout)
                handler.postDelayed(startupTimeout, 12000)
                scheduleListening(700)
            } catch (e: Exception) {
                Log.e(TAG, "SpeechRecognizer initialization failed", e)
                sendStatus(false, "वॉइस रिकग्निशन शुरू नहीं हुआ: ${e.message ?: e.javaClass.simpleName}")
                stopSelf()
            }
        } else {
            sendStatus(false, "इस फोन पर वॉइस रिकग्निशन सेवा उपलब्ध नहीं है।")
            say("इस फोन में वॉइस रिकग्निशन उपलब्ध नहीं है।")
            stopSelf()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopListeningService()
            return START_NOT_STICKY
        }
        // If the user opens AVY and taps Start while this service is already
        // alive, report its real state instead of leaving the button disabled.
        if (recognizerReady) sendStatus(true, "बैकग्राउंड वॉइस मोड पहले से चालू है।")
        return START_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "AVY Voice Assistant", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun scheduleListening(delay: Long = 500) {
        if (!isStopping) {
            handler.removeCallbacks(listenRunnable)
            handler.postDelayed(listenRunnable, delay)
        }
    }

    private val listenRunnable = Runnable {
        if (!isStopping && !isSpeaking && !isProcessingCommand) beginListening()
        else if (!isStopping) scheduleListening(500)
    }

    private fun recreateRecognizer() {
        if (isStopping) return
        try { recognizer?.cancel() } catch (_: Exception) {}
        try { recognizer?.destroy() } catch (_: Exception) {}
        recognizer = null
        recognizerReady = false
        try {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).also {
                it.setRecognitionListener(recognitionListener)
            }
            handler.removeCallbacks(startupTimeout)
            handler.postDelayed(startupTimeout, 12000)
            scheduleListening(900)
        } catch (e: Exception) {
            Log.e(TAG, "Could not recreate SpeechRecognizer", e)
            sendStatus(false, "वॉइस रिकग्निशन दोबारा शुरू नहीं हो पाया: ${e.message ?: e.javaClass.simpleName}")
            scheduleListening(3000)
        }
    }

    private fun beginListening() {
        if (isStopping || isSpeaking || isProcessingCommand) return
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, selectedLocale)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, selectedLocale)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 2)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        try {
            val current = recognizer ?: run { recreateRecognizer(); return }
            current.startListening(intent)
        } catch (e: Exception) {
            Log.w(TAG, "startListening failed; rebuilding recognizer", e)
            recreateRecognizer()
        }
    }

    private val recognitionListener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            recognizerReady = true
            handler.removeCallbacks(startupTimeout)
            recognizerErrorCount = 0
            sendStatus(true, "बैकग्राउंड वॉइस मोड चालू है। AVY सुन रहा है।")
        }
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onError(error: Int) {
            Log.w(TAG, "SpeechRecognizer error=$error")
            recognizerReady = false
            if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                sendStatus(false, "Android ने Speech Recognizer को माइक्रोफोन अनुमति नहीं दी। AVY की ऐप अनुमति जाँचें।")
                stopListeningService()
                return
            }
            recognizerErrorCount++
            // SpeechRecognizer providers can enter a broken binder state after repeated errors.
            // Recreate it instead of repeatedly calling startListening on a failed instance.
            if (recognizerErrorCount >= 3) {
                sendStatus(true, "वॉइस सेवा फिर से कनेक्ट हो रही है (त्रुटि $error)। कृपया AVY को खुला/सक्रिय रखें।")
            }
            if (error == SpeechRecognizer.ERROR_CLIENT || error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY || recognizerErrorCount >= 3) {
                recreateRecognizer()
            } else {
                scheduleListening(if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) 900 else 1800)
            }
        }
        override fun onResults(results: Bundle?) {
            recognizerReady = false
            val command = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
            if (command.isNotBlank()) {
                isProcessingCommand = true
                handleCommand(command)
            } else scheduleListening(500)
        }
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun handleCommand(raw: String) {
        val normalized = raw.lowercase(Locale("hi", "IN"))
        try {
            when {
                normalized.contains("अलार्म") || normalized.contains("जगा") || normalized.contains("alarm") -> {
                    say(AvyTimeCommands.setAlarm(this, raw)); return
                }
                normalized.contains("टाइमर") || normalized.contains("मिनट का") || normalized.contains("सेकंड का") || normalized.contains("घंटे का") || normalized.contains("timer") -> {
                    say(AvyTimeCommands.setTimer(this, raw)); return
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Alarm/timer command failed", e)
            say("अलार्म या टाइमर सेट नहीं हो पाया। फोन की Clock ऐप जाँचें।")
            return
        }
        if (AvyPhoneActions.isAccessibilityCommand(raw) && !AvyPhoneActions.accessibilityEnabled(this)) {
            say("फोन कंट्रोल के लिए AVY ऐप खोलें और Accessibility अनुमति चालू करें।")
            return
        }
        if (AvyPhoneActions.handle(this, raw)) {
            say("जी, कमांड पूरी कर रहा हूँ।")
            return
        }
        val c = raw.lowercase(Locale("hi", "IN")).trim()
        when {
            c.contains("समय") || c.contains("टाइम") -> {
                val time = java.text.SimpleDateFormat("h:mm a", Locale("hi", "IN")).format(java.util.Date())
                say("अभी समय है $time")
            }
            c.contains("यूट्यूब") || c.contains("youtube") -> openUrl("https://www.youtube.com", "यूट्यूब खोल रहा हूँ")
            c.contains("गूगल") || c.contains("सर्च") || c.contains("खोजो") -> {
                val q = raw.replace(Regex("(?i)गूगल पर|गूगल में|सर्च करो|खोजो|खोज कर|सर्च"), "").trim()
                openUrl("https://www.google.com/search?q=" + Uri.encode(q.ifBlank { raw }), "खोज रहा हूँ")
            }
            c.contains("व्हाट्सएप") || c.contains("whatsapp") -> launch("com.whatsapp", "व्हाट्सऐप")
            c.contains("क्रोम") || c.contains("ब्राउज़र") -> launch("com.android.chrome", "ब्राउज़र")
            c.contains("मैप") || c.contains("रास्ता") -> openUrl("https://maps.google.com", "मैप खोल रहा हूँ")
            c.contains("कैमरा") || c.contains("फोटो") -> {
                try { startActivity(Intent("android.media.action.IMAGE_CAPTURE").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); say("कैमरा खोल रहा हूँ") }
                catch (_: Exception) { say("कैमरा नहीं खुल पाया") }
            }
            c.contains("म्यूजिक") || c.contains("गाना") -> openUrl("https://music.youtube.com", "म्यूजिक खोल रहा हूँ")
            c.contains("सेटिंग") -> {
                try { startActivity(Intent(android.provider.Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); say("सेटिंग खोल रहा हूँ") }
                catch (_: Exception) { say("सेटिंग नहीं खुल पाई") }
            }
            c.contains("कॉल") || c.contains("फोन लगाओ") -> {
                val number = Regex("[+]?\\d[\\d\\s-]{7,}").find(raw)?.value?.replace(Regex("[\\s-]"), "")
                if (number != null) {
                    say("$number के लिए डायलर खोल रहा हूँ")
                    startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } else say("कॉल के लिए AVY ऐप खोलकर संपर्क चुनें।")
            }
            else -> {
                say("Gemini से पूछ रहा हूँ")
                GeminiBrain.ask(this, raw) { answer -> handler.post {
                    isProcessingCommand = false
                    if (!isStopping) say(answer) else Unit
                    if (!isStopping && answer.isBlank()) scheduleListening(500)
                } }
            }
        }
    }

    private fun openUrl(url: String, message: String) {
        say(message)
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (_: Exception) { say("लिंक नहीं खुल पाया") }
    }

    private fun launch(pkg: String, label: String) {
        val i = packageManager.getLaunchIntentForPackage(pkg)
        if (i == null) say("$label ऐप नहीं मिला")
        else { say("$label खोल रहा हूँ"); startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }

    private fun say(text: String) {
        if (text.isBlank() || isStopping) {
            isProcessingCommand = false
            scheduleListening(500)
            return
        }
        isSpeaking = true
        val engine = tts
        if (engine == null) {
            pendingSpeech = text
            return
        }
        val result = engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "AVY_BG_${System.nanoTime()}")
        if (result == TextToSpeech.ERROR) {
            isSpeaking = false
            isProcessingCommand = false
            scheduleListening(900)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) { isSpeaking = true }
                override fun onDone(utteranceId: String?) {
                    handler.post {
                        isSpeaking = false
                        isProcessingCommand = false
                        scheduleListening(650)
                    }
                }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    handler.post {
                        isSpeaking = false
                        isProcessingCommand = false
                        scheduleListening(900)
                    }
                }
            })
            tts?.setLanguage(Locale.forLanguageTag(selectedLocale))
            // Lower pitch/rate gives a deeper delivery. Actual male timbre depends
            // on the Hindi voice installed by the phone's TTS engine.
            tts?.setPitch(0.78f)
            tts?.setSpeechRate(0.92f)
            val hindiVoices = tts?.voices.orEmpty().filter { it.locale.language == "hi" }
            val maleCandidate: Voice? = hindiVoices.firstOrNull {
                it.name.contains("male", ignoreCase = true) || it.name.contains("masculine", ignoreCase = true)
            }
            if (maleCandidate != null) tts?.voice = maleCandidate
            pendingSpeech?.let { message ->
                pendingSpeech = null
                handler.post { say(message) }
            }
        } else {
            isSpeaking = false
            isProcessingCommand = false
            scheduleListening(1200)
        }
    }

    private fun sendStatus(ok: Boolean, message: String) {
        getSharedPreferences("avy_settings", MODE_PRIVATE).edit()
            .putBoolean("background_listening_active", ok).apply()
        sendBroadcast(Intent(ACTION_STATUS).setPackage(packageName).putExtra(EXTRA_OK, ok).putExtra(EXTRA_MESSAGE, message))
    }

    private fun stopListeningService() {
        isStopping = true
        getSharedPreferences("avy_settings", MODE_PRIVATE).edit().putBoolean("background_listening_active", false).apply()
        handler.removeCallbacksAndMessages(null)
        try { recognizer?.cancel() } catch (_: Exception) {}
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        isStopping = true
        getSharedPreferences("avy_settings", MODE_PRIVATE).edit().putBoolean("background_listening_active", false).apply()
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_STOP = "com.avy.assistant.STOP_LISTENING"
        const val ACTION_STATUS = "com.avy.assistant.LISTENING_STATUS"
        const val EXTRA_OK = "ok"
        const val EXTRA_MESSAGE = "message"
        private const val TAG = "AVYListeningService"
        private const val CHANNEL_ID = "avy_voice_channel"
        private const val NOTIFICATION_ID = 4107
    }
}
