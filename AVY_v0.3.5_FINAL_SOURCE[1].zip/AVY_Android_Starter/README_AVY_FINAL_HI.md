# AVY AI — Final Source Package v0.3.5

यह आपके मौजूदा AVY Android प्रोजेक्ट `com.avy.assistant` का अगला source revision है। मूल UI reference image, Robot artwork, चार-tab navigation और मौजूदा स्क्रीन संरचना को सुरक्षित रखा गया है। यह APK नहीं, Android Studio/GitHub Actions से build होने वाला source package है।

## डिजाइन लॉक — बिना आपकी अनुमति बदलाव नहीं

1. **Splash / Identity:** मौजूदा Neon Blue Robot artwork और AVY पहचान।
2. **Home:** AVY ब्रांड हेडर, Robot visual, हिंदी स्वागत संदेश, voice status, मुख्य microphone action, background listening control और quick actions।
3. **Chat:** Gemini AI chat, text input और voice input।
4. **Tools:** दो कॉलम में आठ मॉड्यूल — AI Chat, Voice System, Phone Control, App Manager, Internet Tools, Media, Productivity, Custom Commands।
5. **Settings:** Permissions, Security & Privacy, Banking Safe Mode, Voice & Language, AI Model, Gemini Connection Test, Theme, Advanced Settings, Updates, About।
6. **Navigation:** Home / Chat / Tools / Settings के चार स्थायी टैब।
7. **Visual style:** काला futuristic background, neon blue/cyan accents, blue borders, मौजूदा Robot logo और हिंदी-first labels।

मूल संदर्भ फ़ाइल `AVY_UI_Design_Reference.png` प्रोजेक्ट में रखी गई है।

## इस revision में शामिल

- Android package ID `com.avy.assistant` बरकरार। Version `0.3.5`, versionCode `6`।
- Gemini API key फोन के Android Keystore AES/GCM के जरिए encrypt करके रखी जाती है। API key को GitHub, चैट या source code में न डालें।
- Gemini text request, Hindi/बहुभाषी speech recognition और Android Text-to-Speech का मौजूदा integration रखा गया है। Gemini model identifier source में `gemini-3.8-flash` है; वास्तविक API उपलब्धता/मॉडल access को build के बाद Connection Test से सत्यापित करना होगा।
- Foreground microphone service opt-in है; background listening के लिए उपयोगकर्ता को स्पष्ट रूप से Start दबाना और notification दिखना आवश्यक है। यह हमेशा चालू रहने वाला “Hey AVY” wake-word engine नहीं है।
- Alarm और timer Android Clock intents से खुलते हैं। Call action Dialer खोलता है; AVY बिना पुष्टि कॉल नहीं करती।
- Accessibility Service screen content पढ़ने की अनुमति (`canRetrieveWindowContent`) नहीं माँगती।
- Accessibility gestures और global navigation को सामान्य ऐप allowlist तक सीमित किया गया है: YouTube, YouTube Music, Chrome, WhatsApp, Facebook, Instagram, Gmail, Maps और Spotify।
- Google Pay, PhonePe, Paytm, BHIM और सूचीबद्ध बैंकिंग ऐप्स के package names के लिए Accessibility gesture/global action block है।
- About स्क्रीन पर सही attribution: “Designed & developed with ChatGPT AI assistance”; साथ में स्पष्ट है कि AVY OpenAI/ChatGPT का आधिकारिक ऐप नहीं है और वर्तमान AI answers Gemini API से आते हैं।

## बहुत जरूरी Google Pay सीमा

यह package-level control safeguard है, Google Pay compatibility bypass नहीं। Google Pay कुछ Android/Google Play Services versions पर किसी भी enabled third-party Accessibility Service की मौजूदगी को जोखिम मानकर payment block कर सकता है, भले AVY उस समय कोई gesture न चला रही हो। Android किसी सामान्य ऐप को अपनी Accessibility permission चुपचाप revoke करने नहीं देता। अगर Google Pay warning जारी रहे, तो सुरक्षित उपाय है Android Settings → Accessibility → Downloaded apps में AVY को payment करने से पहले manually OFF करना, फिर जरूरत पर वापस ON करना। कोई hidden bypass या Google Pay security circumvention implement नहीं किया गया है।

## Build कैसे होगा

GitHub Actions workflow: `.github/workflows/build-avy.yml`

1. इस ZIP को extract करें। Repository में `AVY_Android_Starter` folder के अंदर की सभी files repository root में रखें (या folder के contents को root पर upload करें)।
2. GitHub में Actions tab खोलें।
3. `Build AVY v0.3.5 APK` workflow चुनें और `Run workflow` दबाएँ।
4. सफल होने पर `AVY-v0.3.5-debug-apk` artifact डाउनलोड करें। उसके अंदर `app-debug.apk` होगा।

आवश्यक toolchain: JDK 17, Android SDK Platform 35, Gradle wrapper 8.9, Android Gradle Plugin 8.7.3।

## फोन पर पहली बार सेटअप

1. AVY install करके microphone permission दें।
2. Settings → AI Model में अपनी Google AI Studio API key सीधे ऐप में डालें। इसे किसी के साथ साझा न करें।
3. Settings → Gemini Connection Test चलाएँ।
4. Phone Control के लिए Android Accessibility Settings में AVY service स्वयं ON करें।
5. Background listening को Home screen के button से स्वयं Start करें; notification में Stop action उपलब्ध है।
6. यदि Google Pay payment block करे, AVY Accessibility को Android Settings से manually OFF करें और फोन restart करके फिर भुगतान जाँचें।

## क्या अभी verified नहीं है

- इस निर्माण वातावरण में Android SDK/Gradle distribution उपलब्ध नहीं था; इसलिए पूर्ण Gradle APK build और वास्तविक Android device QA इस ZIP के साथ दावा नहीं किया जा रहा।
- Google Pay/UPI पर वास्तविक फोन परीक्षण आवश्यक है। Allowlist और protected-package block Google Pay द्वारा Accessibility presence पर लगाए गए block को समाप्त करने की गारंटी नहीं देते।
- Speech recognition, Hindi male TTS voice, background microphone behavior फोन, installed speech provider, TTS engine, Android version और battery settings पर निर्भर हैं।
- Update manifest URL placeholder है; OTA updates अभी configure नहीं हैं।
- Commercial release से पहले Gemini API calls को authenticated backend के पीछे रखना, privacy policy, consent flow, abuse/rate limits, release signing और Play policy review करना जरूरी है।
- Debug APK signing को production release signing न समझें। Debug signature बदलने पर पुराने debug APK पर update fail हो सकता है।

## अगली build के बाद परीक्षण सूची

- [ ] GitHub Actions में assembleDebug सफल
- [ ] APK install / existing app update
- [ ] Gemini Connection Test
- [ ] Hindi speech recognition + TTS
- [ ] Foreground/background listening start-stop
- [ ] YouTube/Chrome/WhatsApp allowlisted navigation
- [ ] Google Pay payment test: यदि warning हो तो Accessibility OFF करके सुरक्षित भुगतान
- [ ] Phone reboot के बाद permissions और service status
