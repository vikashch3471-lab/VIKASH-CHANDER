# AVY Complete Modular Design Source v0.2.0

This package is a revised Android Studio source project based on the supplied AVY project. It keeps the existing applicationId `com.avy.assistant`, increments versionCode to 2/versionName 0.2.0, refreshes the main dashboard into grouped sections, and changes the Gemini text model to `gemini-3.8-flash`.

## Included in this revision
- Neon blue / dark dashboard styling with the existing AVY robot artwork.
- Grouped AI Brain, Voice Center, Phone Control, Smart Tools and App Settings sections.
- Existing speech recognition, Android Text-to-Speech, background listening, Gemini key encryption, and Accessibility phone-action implementation retained.
- Gemini endpoint model string updated to `gemini-3.8-flash`; removed custom temperature override from generation config.
- Modular source folders created for incremental separation: ai, voice, phonecontrol, appmanager, internet, productivity, security, settings, dashboard.

## Important limits
This is a source revision, not a verified APK. It has not been compiled or device-tested in this environment (Android SDK/Gradle build toolchain is not installed here). Some dashboard entries are guidance/entry points and are not separate feature implementations yet. Android special permissions such as microphone and Accessibility still require explicit system approval; an app cannot silently grant them. Google Play Protect should remain enabled.

## Build on Windows
1. Extract this ZIP.
2. Open the `AVY_Android_Starter` folder in Android Studio.
3. Allow Gradle sync.
4. Build > Make Project. Resolve any SDK installation prompt using Android Studio's SDK Manager.
5. Run on a test phone before generating a signed release APK.

## API key security
The current app encrypts the Gemini API key at rest with Android Keystore. For a public/commercial release, do not embed a shared developer API key in the APK. Use a secured backend that authenticates users and protects provider credentials, with rate limits and abuse controls.

## Upgrade caution
The package name is unchanged, but an update can still fail if the signing certificate differs from the installed app. Do not uninstall the old AVY app until a matching-signature update is confirmed and its data is backed up.
