package com.avy.assistant

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import android.util.Base64

/** Gemini text brain. API key is encrypted with an Android Keystore AES key on this device. */
object GeminiBrain {
    private const val PREFS = "avy_secure_brain"
    private const val KEY_ALIAS = "avy_gemini_key_v1"
    private const val MODEL = "gemini-3.8-flash"

    private fun secretKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder(KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true).build())
        return generator.generateKey()
    }

    fun saveApiKey(context: Context, apiKey: String) {
        require(apiKey.isNotBlank())
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, secretKey())
        val encrypted = cipher.doFinal(apiKey.trim().toByteArray(Charsets.UTF_8))
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("iv", Base64.encodeToString(cipher.iv, Base64.NO_WRAP))
            .putString("data", Base64.encodeToString(encrypted, Base64.NO_WRAP)).apply()
    }

    fun hasApiKey(context: Context): Boolean = getApiKey(context).isNotBlank()

    private fun getApiKey(context: Context): String {
        return try {
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val iv = Base64.decode(prefs.getString("iv", "") ?: "", Base64.NO_WRAP)
            val data = Base64.decode(prefs.getString("data", "") ?: "", Base64.NO_WRAP)
            if (iv.isEmpty() || data.isEmpty()) "" else {
                val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                cipher.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(128, iv))
                String(cipher.doFinal(data), Charsets.UTF_8)
            }
        } catch (_: Exception) { "" }
    }

    fun ask(context: Context, prompt: String, callback: (String) -> Unit) {
        val apiKey = getApiKey(context)
        if (apiKey.isBlank()) { callback("Gemini AI चालू करने के लिए AVY की सेटिंग में अपनी Gemini API Key जोड़ें।"); return }
        Thread {
            var answer: String
            var connection: HttpURLConnection? = null
            try {
                val endpoint = "https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent"
                connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"; connectTimeout = 15000; readTimeout = 30000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    setRequestProperty("x-goog-api-key", apiKey)
                }
                val system = "You are AVY, a helpful multilingual Android voice assistant. Detect the language of the user's latest message and reply naturally in that same language. Keep spoken answers concise, clear and safe. If asked to translate, translate faithfully. Do not claim to perform phone actions unless the app explicitly confirms them."
                val body = JSONObject().put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                    .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
                    .put("generationConfig", JSONObject().put("maxOutputTokens", 700))
                connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val code = connection.responseCode
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                val response = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                if (code !in 200..299) {
                    val detail = try { JSONObject(response).getJSONObject("error").optString("message") } catch (_: Exception) { "HTTP $code" }
                    answer = when (code) { 400, 403, 404 -> "Gemini API में समस्या है: $detail"; 429 -> "Gemini की मुफ्त उपयोग सीमा अभी पूरी हो गई है। बाद में कोशिश करें।"; else -> "Gemini से जवाब नहीं मिला: $detail" }
                } else {
                    val json = JSONObject(response)
                    answer = json.getJSONArray("candidates").getJSONObject(0).getJSONObject("content")
                        .getJSONArray("parts").let { parts -> (0 until parts.length()).mapNotNull { parts.optJSONObject(it)?.optString("text") }.joinToString(" ").trim() }
                    if (answer.isBlank()) answer = "Gemini से खाली जवाब मिला। फिर पूछिए।"
                }
            } catch (e: Exception) { answer = "Gemini से कनेक्शन नहीं हो पाया। इंटरनेट और API Key जाँचें।" }
            finally { connection?.disconnect() }
            callback(answer)
        }.start()
    }
}
