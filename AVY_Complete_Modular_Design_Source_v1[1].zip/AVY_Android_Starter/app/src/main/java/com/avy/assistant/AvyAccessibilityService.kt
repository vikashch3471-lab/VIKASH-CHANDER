package com.avy.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.media.AudioManager
import android.os.Build
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

class AvyAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    companion object {
        @Volatile var active: AvyAccessibilityService? = null
    }

    override fun onServiceConnected() { super.onServiceConnected(); active = this }
    override fun onDestroy() { if (active === this) active = null; super.onDestroy() }

    fun swipe(up: Boolean) {
        if (Build.VERSION.SDK_INT < 24) return
        val dm = resources.displayMetrics
        val x = dm.widthPixels / 2f
        val fromY = if (up) dm.heightPixels * .78f else dm.heightPixels * .25f
        val toY = if (up) dm.heightPixels * .25f else dm.heightPixels * .78f
        val path = Path().apply { moveTo(x, fromY); lineTo(x, toY) }
        val gesture = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 450)).build()
        dispatchGesture(gesture, null, null)
    }

    fun tap(xPercent: Int, yPercent: Int) {
        if (Build.VERSION.SDK_INT < 24) return
        val dm = resources.displayMetrics
        val x = dm.widthPixels * (xPercent.coerceIn(0, 100) / 100f)
        val y = dm.heightPixels * (yPercent.coerceIn(0, 100) / 100f)
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 80)).build()
        dispatchGesture(gesture, null, null)
    }
}

object AvyPhoneActions {
    fun accessibilityEnabled(context: Context): Boolean = AvyAccessibilityService.active != null

    fun handle(context: Context, raw: String): Boolean {
        val c = raw.lowercase(java.util.Locale("hi", "IN")).trim()
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        when {
            c.contains("वॉल्यूम बढ़") || c.contains("आवाज बढ़") || c.contains("आवाज़ बढ़") || c.contains("volume up") -> {
                audio.adjustVolume(AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI); return true
            }
            c.contains("वॉल्यूम कम") || c.contains("आवाज कम") || c.contains("आवाज़ कम") || c.contains("volume down") -> {
                audio.adjustVolume(AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI); return true
            }
            c.contains("म्यूट") || c.contains("आवाज बंद") || c.contains("आवाज़ बंद") -> {
                audio.adjustVolume(AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI); return true
            }
            c.contains("अनम्यूट") || c.contains("आवाज चालू") || c.contains("आवाज़ चालू") -> {
                audio.adjustVolume(AudioManager.ADJUST_UNMUTE, AudioManager.FLAG_SHOW_UI); return true
            }
            c.contains("वॉलपेपर") || c.contains("wallpaper") -> {
                val i = Intent(Intent.ACTION_SET_WALLPAPER).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(i); return true
            }
            c.contains("ऊपर स्क्रॉल") || c.contains("ऊपर करो") || c.contains("scroll up") -> {
                AvyAccessibilityService.active?.swipe(true) ?: openAccessibilitySettings(context); return true
            }
            c.contains("नीचे स्क्रॉल") || c.contains("नीचे करो") || c.contains("scroll down") -> {
                AvyAccessibilityService.active?.swipe(false) ?: openAccessibilitySettings(context); return true
            }
            c.contains("वापस जाओ") || c == "बैक" || c.contains("go back") -> {
                AvyAccessibilityService.active?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK) ?: openAccessibilitySettings(context); return true
            }
            c.contains("होम स्क्रीन") || c == "होम" || c.contains("home screen") -> {
                AvyAccessibilityService.active?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME) ?: openAccessibilitySettings(context); return true
            }
            c.contains("हाल की ऐप") || c.contains("recent apps") -> {
                AvyAccessibilityService.active?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS) ?: openAccessibilitySettings(context); return true
            }
            c.contains("नोटिफिकेशन") || c.contains("सूचनाएं") -> {
                AvyAccessibilityService.active?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS) ?: openAccessibilitySettings(context); return true
            }
            c.contains("क्विक सेटिंग") -> {
                AvyAccessibilityService.active?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS) ?: openAccessibilitySettings(context); return true
            }
            c.startsWith("टैप ") || c.startsWith("tap ") -> {
                val nums = Regex("(\\d{1,3})[ ,]+(\\d{1,3})").find(c)
                if (nums != null) AvyAccessibilityService.active?.tap(nums.groupValues[1].toInt(), nums.groupValues[2].toInt()) ?: openAccessibilitySettings(context)
                return true
            }
        }
        return false
    }

    fun openAccessibilitySettings(context: Context) {
        Toast.makeText(context, "फोन कंट्रोल के लिए AVY Accessibility अनुमति चालू करें", Toast.LENGTH_LONG).show()
        try { context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
    }
}
