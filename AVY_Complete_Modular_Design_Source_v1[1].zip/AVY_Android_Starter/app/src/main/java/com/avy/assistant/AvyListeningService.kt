package com.avy.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import android.widget.Toast
import java.util.Locale

/**
 * Opt-in, visible foreground microphone service. Recognition is restarted after
 * each phrase; Android/device speech providers may still stop or throttle it.
 */
class AvyListeningService : Service(), TextToSpeech.OnInitListener {
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private val handler = Handler(Looper.getMainLooper())
    private var isStopping = false
    private var isSpeaking = false
    private val selectedLocale: String by lazy { getSharedPreferences("avy_settings", MODE_PRIVATE).getString("speech_locale", "hi-IN") ?: "hi-IN" }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        val notification = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("AVY सुन रहा है")
            .setContentText("बैकग्राउंड वॉइस मोड चालू है। बंद करने के लिए AVY ऐप खोलें।")
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
        tts = TextToSpeech(this, this)
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).also {
                it.setRecognitionListener(recognitionListener)
            }
            scheduleListening(700)
        } else {
            say("इस फोन में वॉइस रिकग्निशन उपलब्ध नहीं है।")
            stopSelf()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopListeningService()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "AVY Voice Assistant", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun scheduleListening(delay: Long = 500) {
        if (!isStopping) handler.postDelayed({ beginListening() }, delay)
    }

    private fun beginListening() {
        if (isStopping || isSpeaking) return
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, selectedLocale)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, selectedLocale)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 2)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        try { recognizer?.startListening(intent) } catch (_: Exception) { scheduleListening(1800) }
    }

    private val recognitionListener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onError(error: Int) { scheduleListening(1200) }
        override fun onResults(results: Bundle?) {
            val command = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
            if (command.isNotBlank()) handleCommand(command)
            scheduleListening(900)
        }
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun handleCommand(raw: String) {
        if (AvyPhoneActions.handle(this, raw)) {
            say("जी, कमांड पूरी कर रहा हूँ।")
            return
        }
        val c = raw.lowercase(Locale("hi", "IN")).trim()
        when {
            c.contains("समय") || c.contains("टाइम") -> {
                val time = java.text.SimpleDateFormat("h:mm a", Locale("hi", "IN")).format(java.util.Date())
                say("अभी समय है $time")
            }
            c.contains("यूट्यूब") || c.contains("youtube") -> openUrl("https://www.youtube.com", "यूट्यूब खोल रहा हूँ")
            c.contains("गूगल") || c.contains("सर्च") || c.contains("खोजो") -> {
                val q = raw.replace(Regex("(?i)गूगल पर|गूगल में|सर्च करो|खोजो|खोज कर|सर्च"), "").trim()
                openUrl("https://www.google.com/search?q=" + Uri.encode(q.ifBlank { raw }), "खोज रहा हूँ")
            }
            c.contains("व्हाट्सएप") || c.contains("whatsapp") -> launch("com.whatsapp", "व्हाट्सऐप")
            c.contains("क्रोम") || c.contains("ब्राउज़र") -> launch("com.android.chrome", "ब्राउज़र")
            c.contains("मैप") || c.contains("रास्ता") -> openUrl("https://maps.google.com", "मैप खोल रहा हूँ")
            c.contains("कैमरा") || c.contains("फोटो") -> {
                try { startActivity(Intent("android.media.action.IMAGE_CAPTURE").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); say("कैमरा खोल रहा हूँ") }
                catch (_: Exception) { say("कैमरा नहीं खुल पाया") }
            }
            c.contains("म्यूजिक") || c.contains("गाना") -> openUrl("https://music.youtube.com", "म्यूजिक खोल रहा हूँ")
            c.contains("सेटिंग") -> {
                try { startActivity(Intent(android.provider.Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); say("सेटिंग खोल रहा हूँ") }
                catch (_: Exception) { say("सेटिंग नहीं खुल पाई") }
            }
            c.contains("कॉल") || c.contains("फोन लगाओ") -> {
                val number = Regex("[+]?\\d[\\d\\s-]{7,}").find(raw)?.value?.replace(Regex("[\\s-]"), "")
                if (number != null) {
                    say("$number के लिए डायलर खोल रहा हूँ")
                    startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } else say("कॉल के लिए AVY ऐप खोलकर संपर्क चुनें।")
            }
            else -> {
                say("Gemini से पूछ रहा हूँ")
                GeminiBrain.ask(this, raw) { answer -> handler.post { if (!isStopping) say(answer) } }
            }
        }
    }

    private fun openUrl(url: String, message: String) {
        say(message)
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (_: Exception) { say("लिंक नहीं खुल पाया") }
    }

    private fun launch(pkg: String, label: String) {
        val i = packageManager.getLaunchIntentForPackage(pkg)
        if (i == null) say("$label ऐप नहीं मिला")
        else { say("$label खोल रहा हूँ"); startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }

    private fun say(text: String) {
        isSpeaking = true
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "AVY_BG")
        handler.postDelayed({ isSpeaking = false }, 2500)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.setLanguage(Locale.forLanguageTag(selectedLocale))
            // Lower pitch/rate gives a deeper delivery. Actual male timbre depends
            // on the Hindi voice installed by the phone's TTS engine.
            tts?.setPitch(0.78f)
            tts?.setSpeechRate(0.92f)
            val hindiVoices = tts?.voices.orEmpty().filter { it.locale.language == "hi" }
            val maleCandidate: Voice? = hindiVoices.firstOrNull {
                it.name.contains("male", ignoreCase = true) || it.name.contains("masculine", ignoreCase = true)
            }
            if (maleCandidate != null) tts?.voice = maleCandidate
        }
    }

    private fun stopListeningService() {
        isStopping = true
        handler.removeCallbacksAndMessages(null)
        try { recognizer?.cancel() } catch (_: Exception) {}
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        isStopping = true
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_STOP = "com.avy.assistant.STOP_LISTENING"
        private const val CHANNEL_ID = "avy_voice_channel"
        private const val NOTIFICATION_ID = 4107
    }
}
