# AVY Complete Android Source (Gemini + Phone Control)

यह एकल Android Studio source project है। इसमें Gemini API integration, foreground background voice service, Accessibility आधारित सीमित phone actions, भाषा चयन और launcher icon शामिल हैं।

## शामिल सुविधाएँ
- Gemini text Q&A (`gemini-2.5-flash` API endpoint); API key उपयोगकर्ता AVY में स्वयं डालता है और Android Keystore से encrypt होकर local device पर रहती है।
- Hindi सहित speech locale selection; Android Text-to-Speech engine उपलब्ध voice ही बोल सकता है। AVY में TTS settings खोलने का बटन दिया है ताकि voice data/voice विकल्प सेट किए जा सकें।
- ऐप foreground में auto-listen प्रयास।
- वैकल्पिक visible foreground microphone service; notification दिखाई देती है।
- Background service में भी supported volume, scroll, back, home, recents, notifications, quick settings, wallpaper chooser commands।
- App launch/search, dialer, camera, settings और alarm intents।
- Accessibility service gestures के लिए स्पष्ट user opt-in।
- AVY launcher icon।

## पहली बार सेटअप
1. Android 8+ और microphone permission दें।
2. Gemini AI बटन में अपनी निजी Google AI Studio API key डालें। Key किसी से साझा न करें।
3. Phone Control बटन दबाकर Android Accessibility settings में AVY Phone Control को स्वयं enable करें।
4. Background listening चालू करने के लिए AVY के अंदर उसका बटन दबाएँ और notification permission दें।
5. पुरुष Hindi voice यदि फोन के engine में उपलब्ध हो तो TTS settings में चुनें। Voice Data/Install voice data विकल्प से Hindi data डाउनलोड करें यदि उपलब्ध हो।

## वास्तविक सीमाएँ
- यह हमेशा सक्रिय “Hey AVY” hotword engine नहीं है। Android SpeechRecognizer को वाक्य-दर-वाक्य पुनः शुरू किया जाता है। Android/OEM बैटरी और microphone restrictions इसे रोक सकते हैं; लॉक स्क्रीन पर लगातार सुनने की गारंटी नहीं।
- Android में Hindi male voice हर TTS engine/device पर उपलब्ध नहीं होती। AVY उपलब्ध male-labelled Hindi voice चुनने का प्रयास करता है; pitch कम करना असली male voice की गारंटी नहीं है। यदि कोई male Hindi voice सूची में नहीं है तो Settings में उपलब्ध voice data डाउनलोड करें या दूसरे TTS engine की आवश्यकता होगी।
- Accessibility gestures केवल अनुमत और gesture-supported screens पर काम करते हैं। बैंकिंग/सुरक्षित स्क्रीन, permission dialogs और कुछ third-party apps को नियंत्रित नहीं किया जा सकता। Tap command का format `tap 50 50` (screen percentage) है।
- Wallpaper command Android का wallpaper chooser खोलती है; स्वयं फोटो चुनकर लागू नहीं करती। Call command dialer खोलती है, बिना पुष्टि कॉल नहीं करती।
- API key को device पर encrypt करना storage-at-rest सुरक्षा है, पूर्ण secret-management नहीं। सार्वजनिक commercial release से पहले server-side backend और abuse controls आवश्यक हैं।
- इस package में कोई prebuilt APK नहीं है। GitHub Actions/Android SDK build और वास्तविक device tests आवश्यक हैं।

## Build requirements
JDK 17, Android SDK Platform 35, Gradle wrapper 8.9, Android Gradle Plugin 8.7.3. GitHub Actions workflow नीचे `.github/workflows/build-avy.yml` में है।

## Build on GitHub Actions
Repository में `AVY_Complete_Phone_Control_Gemini.zip` upload करें और workflow file `.github/workflows/build-avy.yml` रखें। Actions tab से `Build AVY Complete Android APK` चलाएँ। Artifact `AVY-Complete-debug-apk` डाउनलोड करें। Debug APK परीक्षण के लिए है, Play Store release के लिए signed release build/backend आवश्यक है।
