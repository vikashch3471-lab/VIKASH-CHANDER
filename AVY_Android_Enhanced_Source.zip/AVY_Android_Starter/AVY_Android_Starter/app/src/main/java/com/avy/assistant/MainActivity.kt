package com.avy.assistant

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private lateinit var statusText: TextView
    private lateinit var heardText: TextView
    private lateinit var listenButton: Button
    private lateinit var backgroundButton: Button
    private val audioPermissionRequest = 100
    private val contactRequest = 101
    private var pendingBackgroundStart = false
    private val mainHandler = Handler(Looper.getMainLooper())
    private var activityResumed = false
    private var isListening = false
    private var isSpeaking = false
    private var autoListeningEnabled = true
    private var backgroundModeActive = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildScreen()
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
            speechRecognizer?.setRecognitionListener(listener)
        } else {
            statusText.text = "इस फोन पर वॉइस रिकग्निशन उपलब्ध नहीं है।"
        }
        greet()
        requestMicrophoneAndStartIfAllowed()
    }

    override fun onResume() {
        super.onResume()
        activityResumed = true
        if (!backgroundModeActive && ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            scheduleAutoListening(500)
        }
    }

    override fun onPause() {
        activityResumed = false
        mainHandler.removeCallbacksAndMessages(null)
        try { speechRecognizer?.cancel() } catch (_: Exception) {}
        isListening = false
        super.onPause()
    }

    private fun requestMicrophoneAndStartIfAllowed() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), audioPermissionRequest)
        } else {
            if (!backgroundModeActive) scheduleAutoListening(700)
        }
    }

    private fun scheduleAutoListening(delayMs: Long = 700) {
        if (!autoListeningEnabled || backgroundModeActive || !activityResumed || isListening || isSpeaking) return
        mainHandler.removeCallbacks(autoListenRunnable)
        mainHandler.postDelayed(autoListenRunnable, delayMs)
    }

    private val autoListenRunnable = Runnable {
        if (autoListeningEnabled && !backgroundModeActive && activityResumed && !isListening && !isSpeaking) startListening()
    }

    private fun buildScreen() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 48, 32, 40)
            setBackgroundColor(android.graphics.Color.rgb(5, 17, 34))
        }
        val title = TextView(this).apply {
            text = "AVY"
            textSize = 42f
            setTextColor(android.graphics.Color.rgb(67, 220, 255))
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "आपका हिंदी AI असिस्टेंट"
            textSize = 18f
            setTextColor(android.graphics.Color.WHITE)
            gravity = Gravity.CENTER
        }
        statusText = TextView(this).apply {
            text = "ऐप खुलते ही AVY आपकी आवाज़ सुनेगा"
            textSize = 17f
            setTextColor(android.graphics.Color.rgb(170, 220, 240))
            gravity = Gravity.CENTER
            setPadding(0, 42, 0, 18)
        }
        heardText = TextView(this).apply {
            text = "आपकी आवाज़ यहाँ दिखाई देगी"
            textSize = 16f
            setTextColor(android.graphics.Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 30)
        }
        listenButton = Button(this).apply {
            text = "🎙 अभी सुनें"
            textSize = 18f
            setOnClickListener { autoListeningEnabled = true; startListening() }
        }
        val help = TextView(this).apply {
            text = "उदाहरण: समय बताओ • गूगल पर मौसम खोजो • यूट्यूब खोलो • 9876543210 पर कॉल करो • अलार्म लगाओ"
            textSize = 14f
            setTextColor(android.graphics.Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 30, 0, 0)
        }
        layout.addView(title)
        layout.addView(subtitle)
        layout.addView(statusText)
        layout.addView(heardText)
        layout.addView(listenButton)
        backgroundButton = Button(this).apply {
            text = "▶ बैकग्राउंड सुनना चालू करें"
            textSize = 16f
            setOnClickListener { toggleBackgroundListening() }
        }
        layout.addView(backgroundButton)
        val updateButton = Button(this).apply {
            text = "अपडेट जाँचें"
            setOnClickListener { checkForUpdates() }
        }
        layout.addView(updateButton)
        layout.addView(help)
        setContentView(layout)
    }

    private fun toggleBackgroundListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            pendingBackgroundStart = true
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), audioPermissionRequest)
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 102)
            return
        }
        val intent = Intent(this, AvyListeningService::class.java)
        try {
            autoListeningEnabled = false
            backgroundModeActive = true
            mainHandler.removeCallbacks(autoListenRunnable)
            try { speechRecognizer?.cancel() } catch (_: Exception) {}
            isListening = false
            ContextCompat.startForegroundService(this, intent)
            backgroundButton.text = "■ बैकग्राउंड सुनना बंद करें"
            backgroundButton.setOnClickListener {
                stopService(Intent(this, AvyListeningService::class.java))
                backgroundModeActive = false
                autoListeningEnabled = true
                backgroundButton.text = "▶ बैकग्राउंड सुनना चालू करें"
                backgroundButton.setOnClickListener { toggleBackgroundListening() }
                speak("बैकग्राउंड सुनना बंद कर दिया")
                scheduleAutoListening(1200)
            }
            speak("बैकग्राउंड वॉइस मोड चालू कर रहा हूँ")
        } catch (_: Exception) {
            speak("बैकग्राउंड मोड शुरू नहीं हो पाया। माइक्रोफोन अनुमति जाँचें।")
        }
    }

    private fun startListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), audioPermissionRequest)
            return
        }
        val recognizer = speechRecognizer ?: return
        if (isListening || !activityResumed) return
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "एवी सुन रहा है...")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        statusText.text = "सुन रहा हूँ... अब सीधे बोलिए।"
        listenButton.isEnabled = false
        try {
            isListening = true
            recognizer.startListening(intent)
        } catch (e: Exception) {
            isListening = false
            listenButton.isEnabled = true
            statusText.text = "वॉइस शुरू नहीं हो पाई। फिर कोशिश कर रहा हूँ।"
            scheduleAutoListening(1800)
        }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) { statusText.text = "बोलिए, मैं सुन रहा हूँ..." }
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() { statusText.text = "समझ रहा हूँ..." }
        override fun onError(error: Int) {
            isListening = false
            listenButton.isEnabled = true
            statusText.text = "फिर से सुनने की तैयारी..."
            scheduleAutoListening(1400)
        }
        override fun onResults(results: Bundle?) {
            isListening = false
            listenButton.isEnabled = true
            val words = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            val command = words?.firstOrNull().orEmpty()
            if (command.isNotBlank()) {
                heardText.text = "आपने कहा: $command"
                handleCommand(command)
            } else scheduleAutoListening(500)
        }
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun handleCommand(raw: String) {
        val command = raw.lowercase(Locale("hi", "IN")).trim()
        when {
            command.contains("समय") || command.contains("टाइम") ->
                speak("अभी समय है " + SimpleDateFormat("h:mm a", Locale("hi", "IN")).format(Date()))
            command.contains("यूट्यूब") || command.contains("youtube") ->
                openUrl("https://www.youtube.com", "यूट्यूब खोल रहा हूँ")
            command.contains("गूगल") || command.contains("सर्च") || command.contains("खोजो") ->
                searchGoogle(command, raw)
            command.contains("अलार्म") ->
                setAlarm()
            command.contains("कॉल") || command.contains("फोन लगाओ") ->
                makeCall(raw)
            command.contains("व्हाट्सएप") || command.contains("whatsapp") ->
                launchApp("com.whatsapp", "व्हाट्सऐप")
            command.contains("मैप") || command.contains("रास्ता") ->
                openUrl("https://maps.google.com", "मैप खोल रहा हूँ")
            command.contains("गाना") || command.contains("म्यूजिक") || command.contains("संगीत") ->
                openMusic()
            command.contains("क्रोम") || command.contains("ब्राउज़र") ->
                launchApp("com.android.chrome", "ब्राउज़र")
            command.contains("सेटिंग") ->
                startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
            command.contains("सुनना बंद") || command.contains("एवी बंद") || command.contains("रुको एवी") -> {
                autoListeningEnabled = false
                mainHandler.removeCallbacks(autoListenRunnable)
                speak("ठीक है, मैंने सुनना बंद कर दिया है। फिर शुरू करने के लिए अभी सुनें दबाएँ।")
            }
            command.contains("बंद") || command.contains("रुको") -> speak("ठीक है।")
            else -> speak("मैंने सुना: $raw। इस कमांड को अभी सीखना बाकी है। आप गूगल पर इसकी खोज करवा सकते हैं।")
        }
    }

    private fun searchGoogle(command: String, original: String) {
        val cleaned = original.replace(Regex("(?i)गूगल पर|गूगल में|सर्च करो|खोजो|खोज कर|सर्च"), "").trim()
        val query = if (cleaned.isBlank()) original else cleaned
        openUrl("https://www.google.com/search?q=" + Uri.encode(query), "गूगल पर खोज रहा हूँ: $query")
    }

    private fun openUrl(url: String, message: String) {
        speak(message)
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        catch (_: Exception) { speak("यह लिंक खोलने में परेशानी हुई।") }
    }

    private fun launchApp(packageName: String, label: String) {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) {
            speak("$label खोल रहा हूँ")
            startActivity(launch)
        } else speak("$label ऐप इस फोन में नहीं मिला।")
    }

    private fun makeCall(raw: String) {
        val number = Regex("[+]?\\d[\\d\\s-]{7,}").find(raw)?.value?.replace(Regex("[\\s-]"), "")
        if (number != null) {
            speak("$number के लिए डायलर खोल रहा हूँ")
            startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")))
        } else {
            speak("कॉन्टैक्ट चुनने के लिए संपर्क सूची खोल रहा हूँ")
            val pick = Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI)
            startActivityForResult(pick, contactRequest)
        }
    }

    @Deprecated("Legacy contact picker callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == contactRequest && resultCode == RESULT_OK && data?.data != null) {
            val cursor = contentResolver.query(data.data!!,
                arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER), null, null, null)
            cursor?.use {
                if (it.moveToFirst()) {
                    val number = it.getString(0)
                    startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")))
                }
            }
        }
    }

    private fun setAlarm() {
        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, 7)
            putExtra(AlarmClock.EXTRA_MINUTES, 0)
            putExtra(AlarmClock.EXTRA_MESSAGE, "AVY अलार्म")
            putExtra(AlarmClock.EXTRA_SKIP_UI, false)
        }
        try {
            speak("अलार्म सेट करने की स्क्रीन खोल रहा हूँ। समय चुन लें।")
            startActivity(intent)
        } catch (_: Exception) { speak("इस फोन में अलार्म ऐप उपलब्ध नहीं है।") }
    }

    private fun openMusic() {
        val candidates = listOf("com.spotify.music", "com.google.android.apps.youtube.music",
            "com.google.android.music", "com.sec.android.app.music")
        val pkg = candidates.firstOrNull { packageManager.getLaunchIntentForPackage(it) != null }
        if (pkg != null) launchApp(pkg, "म्यूजिक ऐप")
        else openUrl("https://music.youtube.com", "म्यूजिक खोल रहा हूँ")
    }


    // अपनी HTTPS release-manifest URL यहाँ डालें। Manifest में versionCode,
    // versionName, apkUrl और notes फ़ील्ड होने चाहिए।
    private val updateManifestUrl = "https://YOUR-DOMAIN.example/avy/update.json"

    private fun checkForUpdates() {
        statusText.text = "AVY के अपडेट जाँच रहा हूँ..."
        Thread {
            var resultMessage = "अभी कोई नया अपडेट उपलब्ध नहीं है।"
            var updateInfo: JSONObject? = null
            var failure: String? = null
            try {
                val connection = (URL(updateManifestUrl).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 8000
                    readTimeout = 8000
                    requestMethod = "GET"
                }
                try {
                    if (!updateManifestUrl.startsWith("https://")) {
                        throw IllegalStateException("अपडेट सर्वर का लिंक HTTPS होना चाहिए।")
                    }
                    val body = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                    val json = JSONObject(body)
                    val latestCode = json.optInt("versionCode", 0)
                    val currentCode = packageManager.getPackageInfo(packageName, 0).versionCode
                    if (latestCode > currentCode) {
                        val apkUrl = json.optString("apkUrl", "")
                        if (!apkUrl.startsWith("https://")) {
                            throw IllegalStateException("अपडेट APK का सुरक्षित HTTPS लिंक उपलब्ध नहीं है।")
                        }
                        updateInfo = json
                    }
                } finally {
                    connection.disconnect()
                }
            } catch (e: Exception) {
                failure = e.message ?: "अपडेट जाँच नहीं हो सकी।"
            }
            runOnUiThread {
                val info = updateInfo
                when {
                    failure != null -> {
                        statusText.text = "अपडेट जाँच में समस्या आई।"
                        Toast.makeText(this, failure, Toast.LENGTH_LONG).show()
                    }
                    info != null -> {
                        val version = info.optString("versionName", "नया संस्करण")
                        val notes = info.optString("notes", "नई सुविधाएँ और सुधार")
                        AlertDialog.Builder(this)
                            .setTitle("AVY का अपडेट उपलब्ध है")
                            .setMessage("$version\n\n$notes\n\nडाउनलोड पेज खोलें?")
                            .setNegativeButton("बाद में", null)
                            .setPositiveButton("डाउनलोड") { _, _ ->
                                val link = info.optString("apkUrl")
                                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link)))
                            }
                            .show()
                        statusText.text = "नया अपडेट उपलब्ध है।"
                        speak("एवी का नया अपडेट उपलब्ध है।")
                    }
                    else -> {
                        statusText.text = resultMessage
                        speak(resultMessage)
                    }
                }
            }
        }.start()
    }

    private fun greet() { statusText.post { statusText.text = "AVY तैयार है। अब सीधे बोलिए, बटन दबाने की जरूरत नहीं है।" } }

    private fun speak(message: String) {
        statusText.text = message
        isSpeaking = true
        val result = tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "AVY_SPEECH")
        if (result == TextToSpeech.ERROR || tts == null) {
            isSpeaking = false
            scheduleAutoListening(900)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) { isSpeaking = true }
                override fun onDone(utteranceId: String?) {
                    isSpeaking = false
                    runOnUiThread { scheduleAutoListening(650) }
                }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    isSpeaking = false
                    runOnUiThread { scheduleAutoListening(900) }
                }
            })
            val result = tts?.setLanguage(Locale("hi", "IN"))
            tts?.setPitch(0.78f)
            tts?.setSpeechRate(0.92f)
            val maleVoice = tts?.voices?.firstOrNull {
                it.locale.language == "hi" && it.name.contains("male", ignoreCase = true)
            }
            if (maleVoice != null) tts?.voice = maleVoice
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                statusText.post { statusText.text = "हिंदी आवाज़ के लिए फोन में हिंदी TTS भाषा इंस्टॉल करें।" }
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == audioPermissionRequest && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            if (pendingBackgroundStart) {
                pendingBackgroundStart = false
                toggleBackgroundListening()
            } else {
                autoListeningEnabled = true
                scheduleAutoListening(500)
            }
        } else if (requestCode == audioPermissionRequest) {
            pendingBackgroundStart = false
            Toast.makeText(this, "वॉइस कमांड के लिए माइक्रोफोन अनुमति जरूरी है।", Toast.LENGTH_LONG).show()
        } else if (requestCode == 102 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            toggleBackgroundListening()
        } else if (requestCode == 102) {
            Toast.makeText(this, "बैकग्राउंड नोटिफिकेशन अनुमति जरूरी है।", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        mainHandler.removeCallbacksAndMessages(null)
        speechRecognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
