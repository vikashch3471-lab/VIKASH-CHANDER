# AVY – Android Starter (enhanced source)

यह संस्करण बैकग्राउंड वॉइस मोड के लिए opt-in Android foreground microphone service जोड़ता है।

## नया क्या है
- ऐप में "बैकग्राउंड सुनना चालू करें" बटन।
- माइक्रोफोन foreground service और स्थायी notification।
- हर पहचाने गए वाक्य के बाद SpeechRecognizer को फिर से शुरू करने का प्रयास।
- बैकग्राउंड में YouTube, Google Search, Maps, WhatsApp, Chrome, Camera, Settings और Dialer खोलने के कुछ हिंदी कमांड।
- हिंदी TTS पर कम pitch और धीमी speech rate; यदि इंस्टॉल किए गए Hindi TTS voices में नाम में "male" उपलब्ध है तो उसे चुनने का प्रयास।

## महत्वपूर्ण सीमाएँ
- यह हमेशा चालू रहने वाला "Hey AVY" wake-word engine नहीं है। यह opt-in foreground microphone mode है, जिसमें Android SpeechRecognizer वाक्य-दर-वाक्य सुनता है।
- Android/फोन निर्माता बैकग्राउंड माइक्रोफोन, बैटरी ऑप्टिमाइजेशन और Speech Recognition provider को रोक या सीमित कर सकते हैं। स्क्रीन बंद होने पर लगातार पहचान की गारंटी नहीं है।
- पुरुष आवाज़ की वास्तविक उपलब्धता फोन के TTS इंजन और डाउनलोड किए गए Hindi voice data पर निर्भर है। कम pitch से आवाज़ भारी होती है, लेकिन हर इंजन इसे पुरुष आवाज़ में नहीं बदलता।
- पूर्ण Jarvis जैसी AI बातचीत के लिए सुरक्षित AI backend/API और इंटरनेट कनेक्शन अभी जोड़ा जाना बाकी है। इस प्रोजेक्ट में API key शामिल नहीं है।
- ऐप स्वयं से WhatsApp संदेश नहीं भेजता और कॉल नहीं करता; सुरक्षित Android intents/Dialer खोलता है।
- अपडेट जाँचने का URL placeholder है; वास्तविक रिलीज़ सर्वर/हस्ताक्षरित APK अभी कॉन्फ़िगर नहीं है।

## Build
Android Studio में `AVY_Android_Starter` प्रोजेक्ट खोलें। Android SDK Platform 35 और JDK 17 रखें। Gradle wrapper 8.9 और Android Gradle Plugin 8.7.3 उपयोग किए गए हैं। Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।

## पहली बार चलाने पर
1. माइक्रोफोन अनुमति दें।
2. बैकग्राउंड मोड बटन दबाएँ और notification अनुमति दें।
3. AVY की स्थायी notification दिखेगी। ऐप बंद/दूसरी स्क्रीन पर जाने पर भी सेवा चलने का प्रयास करेगी।
4. बंद करने के लिए AVY ऐप में वही बटन दबाएँ। यदि Android सेवा रोक दे, ऐप दोबारा खोलकर मोड चालू करें।
5. हिंदी TTS के लिए Settings > Accessibility > Text-to-speech output में Hindi voice data इंस्टॉल करें। उपलब्ध voice engine में पुरुष आवाज़ हो तो उसे चुनें।

## Privacy
बैकग्राउंड मोड चालू होने पर माइक्रोफोन का उपयोग होता है और Android notification दिखाई जाती है। मोड बंद करने पर service माइक्रोफोन सुनना बंद करती है।
