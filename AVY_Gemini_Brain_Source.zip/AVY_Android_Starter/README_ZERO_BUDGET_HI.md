# AVY Zero-Budget Development — हिंदी मार्गदर्शिका

## इस पैकेज में अभी क्या बदला है
- ऐप में भाषा चुनने का बटन जोड़ा गया है। चुनी भाषा `SharedPreferences` में सेव होती है।
- चुनी हुई locale ऐप के SpeechRecognizer और TextToSpeech को दी जाती है।
- बैकग्राउंड listening service भी वही सेव की गई locale पढ़ती है।
- हिंदी, भारतीय भाषाओं और कई अंतरराष्ट्रीय भाषाओं के विकल्प जोड़े गए हैं।

## महत्वपूर्ण सीमाएँ
- भाषा सूची में विकल्प दिखना उस भाषा के Speech-to-Text या Text-to-Speech समर्थन की गारंटी नहीं है। यह Android फोन के Speech Recognition provider और इंस्टॉल TTS voice पर निर्भर है।
- हरियाणवी/भोजपुरी जैसे कुछ विकल्प फिलहाल हिंदी locale पर आधारित हैं; ये स्वतंत्र भाषा मॉडल नहीं हैं।
- इस पैकेज में अभी Gemini AI Backend, वास्तविक live translation, Firebase Authentication, Google Login, subscription/payment processing या owner dashboard सक्रिय नहीं हैं। इनके लिए अलग backend/Firebase project configuration और परीक्षण चाहिए।
- Firebase Spark plan में कुछ Authentication/Firestore सुविधाएँ मुफ्त सीमा में उपलब्ध हो सकती हैं, पर सभी सेवाएँ/उपयोग असीमित मुफ्त नहीं हैं। कोई billing-enabled सेवा चालू करने से पहले खर्च की सीमा और alerts सेट करें।
- API key को Android APK या GitHub repository में न रखें। भविष्य में इसे server-side secret के रूप में रखें।
- हमेशा सुनने वाला wake-word engine शामिल नहीं है। Android foreground microphone service user opt-in और OS प्रतिबंधों के अधीन है।

## ₹0 योजना
1. अभी Android ऐप और भाषा चयन को बिना paid service के जाँचें।
2. Firebase project बाद में उपयोगकर्ता स्वयं बनाए; Email/Password और Google provider सक्षम करने के लिए Firebase config (`google-services.json`) और OAuth SHA fingerprints आवश्यक होंगे। इन्हें अभी package में नहीं रखा गया है।
3. Gemini/translation calls को सुरक्षित backend से जोड़ें; बिना backend के API key ऐप में न डालें।
4. Google Play Console और payment gateway को तब तक न जोड़ें जब तक बजट उपलब्ध न हो।

## Build
GitHub Actions workflow `build-avy.yml` इस प्रोजेक्ट को Android Debug APK के रूप में compile करता है और unit-test task चलाता है। GitHub-hosted runner को Gradle/Android dependencies डाउनलोड करने के लिए इंटरनेट चाहिए।
